export { AuthorEdit as default } from './editAuthor';
