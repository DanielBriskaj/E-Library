import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import NewBookForm from '../NewBookForm';
import * as yup from 'yup';
import InputFormItem from '../InputFormItem';
import { i18n } from '../../i18n';
import { changeUserPassword } from '../../redux/slices/Users/usersSlice';
import { ReactComponent as Eye } from '../../assets/svgIcons/eye.svg';
import { ReactComponent as EyeSlash } from '../../assets/svgIcons/eye-slash.svg';

interface ChangePasswordProps {
  toggle: any;
}

export const ChangePassword: React.FunctionComponent<ChangePasswordProps> = ({
  toggle,
}) => {
  const dispatch = useDispatch();
  const [viewOldPass, setViewOldPass] = useState(false);
  const [viewNewPass, setViewNewPass] = useState(false);
  const schema = yup.object().shape({
    passwordVjeter: yup
      .string()
      .nullable()
      .min(4, i18n(`userErrors.password.min`))
      .max(250, i18n(`userErrors.password.max`))
      .required(i18n(`userErrors.password.old`)),
    passwordRi: yup
      .string()
      .nullable()
      .min(4, i18n(`userErrors.password.min`))
      .max(250, i18n(`userErrors.password.max`))
      .required(i18n(`userErrors.password.new`)),
    confirmPassword: yup
      .string()
      .oneOf(
        [yup.ref('passwordRi'), null],
        i18n(`userErrors.confirmPassword.matches`),
      )
      .required(i18n(`userErrors.confirmPassword.new`)),
  });
  const [initialValues] = useState(() => {
    return {
      passwordVjeter: null,
      passwordRi: null,
    };
  });

  const changePassword = (data: any) => {
    dispatch(changeUserPassword(data));
    toggle(false);
  };
  const handleError = () => {
    console.log('error');
  };

  return (
    <div className="password-edit-container">
      <div className="password-edit-wrapper">
        <div className="title">
          <h2>{i18n(`buttons.changePassword`)}</h2>
        </div>
        <div className="password-details" style={{ width: '100%' }}>
          <NewBookForm
            schema={schema}
            onHandleSuccess={changePassword}
            onHandleError={handleError}
            initialValues={initialValues}
          >
            <div className="password-data">
              <div className="password-container">
                <InputFormItem
                  name="passwordVjeter"
                  placeholder={i18n(`userData.oldPassword`)}
                  type={viewOldPass === true ? 'text' : 'password'}
                />
                {viewOldPass === true ? (
                  <EyeSlash
                    className="eye-svg"
                    onClick={() => setViewOldPass(!viewOldPass)}
                  />
                ) : (
                  <Eye
                    className="eye-svg"
                    onClick={() => setViewOldPass(!viewOldPass)}
                  />
                )}
              </div>
              <div className="password-container">
                <InputFormItem
                  name="passwordRi"
                  placeholder={i18n(`userData.newPassword`)}
                  type={viewNewPass === true ? 'text' : 'password'}
                />
                {viewNewPass === true ? (
                  <EyeSlash
                    className="eye-svg"
                    onClick={() => setViewNewPass(!viewNewPass)}
                  />
                ) : (
                  <Eye
                    className="eye-svg"
                    onClick={() => setViewNewPass(!viewNewPass)}
                  />
                )}
              </div>
              <div className="password-container">
                <InputFormItem
                  name="confirmPassword"
                  placeholder={i18n(`userData.verifyPassword`)}
                  type={viewNewPass === true ? 'text' : 'password'}
                />
                {viewNewPass === true ? (
                  <EyeSlash
                    className="eye-svg"
                    onClick={() => setViewNewPass(!viewNewPass)}
                  />
                ) : (
                  <Eye
                    className="eye-svg"
                    onClick={() => setViewNewPass(!viewNewPass)}
                  />
                )}
              </div>
            </div>
            <div className="password-edit-buttons">
              <button
                type="button"
                className="btn-secondary"
                onClick={() => toggle(false)}
              >
                {i18n(`buttons.cancel`)}
              </button>
              <button type="submit" className="btn-primary">
                {i18n(`buttons.saveChanges`)}
              </button>
            </div>
          </NewBookForm>
        </div>
      </div>
    </div>
  );
};
