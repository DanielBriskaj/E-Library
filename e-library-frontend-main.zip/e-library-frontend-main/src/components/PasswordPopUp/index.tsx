export { ChangePassword as default } from './password';
