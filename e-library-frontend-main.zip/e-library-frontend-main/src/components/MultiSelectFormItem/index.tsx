export { MultiSelectFormItem as default } from './multiSelectFormItem';
