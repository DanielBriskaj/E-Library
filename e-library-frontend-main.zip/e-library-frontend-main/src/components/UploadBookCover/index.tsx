export { UploadBookCover as default } from './uploadBookCover';
