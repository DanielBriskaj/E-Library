export { DeleteWindow as default } from './deleteWindow';
