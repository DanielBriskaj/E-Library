export { ConfirmWindow as default } from './confirmWindow';
