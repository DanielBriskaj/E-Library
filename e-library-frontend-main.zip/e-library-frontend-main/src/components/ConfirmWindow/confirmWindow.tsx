import React, { useState } from 'react';
import { i18n } from '../../i18n';

interface ConfirmWindowProps {
  toggle?: any;
  openFile?: any;
  libraryRemove?: any;
  toggleFavorite?: any;
}

export const ConfirmWindow: React.FunctionComponent<ConfirmWindowProps> = ({
  toggle,
  openFile,
  libraryRemove,
  toggleFavorite,
}) => {
  const handleConfirm = () => {
    if (toggle) {
      toggle(false);
      openFile(true);
    } else if (libraryRemove) {
      libraryRemove();
      toggleFavorite(false);
    }
  };
  const handleClose = () => {
    if (toggle) {
      toggle(false);
    } else {
      toggleFavorite(false);
    }
  };
  return (
    <div className="paywall-container">
      <div className="paywall-wrapper">
        <div className="title">
          <h2>
            {toggle
              ? i18n(`payWall.title`)
              : i18n(`singleBookPage.removeFavorite.title`)}
          </h2>
        </div>
        <div className="paywall-info">
          <span className="paywall-description">
            {toggle
              ? i18n(`payWall.description`)
              : i18n(`singleBookPage.removeFavorite.description`)}
          </span>
          <div className="paywall-buttons">
            <button
              className="btn-secondary"
              onClick={() => {
                handleClose();
              }}
            >
              {toggle ? i18n(`buttons.cancel`) : i18n(`buttons.no`)}
            </button>
            <button
              className="btn-primary"
              onClick={() => {
                handleConfirm();
              }}
            >
              {toggle ? i18n(`buttons.continue`) : i18n(`buttons.yes`)}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
