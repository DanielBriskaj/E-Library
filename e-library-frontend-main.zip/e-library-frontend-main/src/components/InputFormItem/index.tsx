export { InputFormItem as default } from './inputFormItem';
