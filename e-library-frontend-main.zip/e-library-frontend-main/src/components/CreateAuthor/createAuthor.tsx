import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import NewBookForm from '../NewBookForm';
import * as yup from 'yup';
import InputFormItem from '../InputFormItem';
import { createAuthor } from '../../redux/slices/Authors/authorsSlice';
import { createAuthorTransformer } from '../../helpers/createAuthorTransformer';
import { i18n } from '../../i18n';

interface CreateAuthorProps {
  toggle: any;
}

export const CreateAuthor: React.FunctionComponent<CreateAuthorProps> = ({
  toggle,
}) => {
  const dispatch = useDispatch();
  const schema = yup.object().shape({
    emriPlote: yup
      .string()
      .nullable()
      .max(70, i18n(`manageAuthors.createAuthors.errors.max`))
      .required(i18n(`manageAuthors.createAuthors.errors.name`)),
    ditelindja: yup
      .date()
      .nullable()
      .min(
        '1000-01-01',
        i18n(`manageAuthors.createAuthors.errors.invalidBirthday`),
      )
      .max(
        new Date(),
        i18n(`manageAuthors.createAuthors.errors.invalidBirthday`),
      )
      .required(i18n(`manageAuthors.createAuthors.errors.reqBirthday`)),
  });
  const [initialValues] = useState(() => {
    return {
      emriPlote: null,
      ditelindja: null,
    };
  });

  const createAuthors = (data: any) => {
    const transformedData = createAuthorTransformer(data);
    dispatch(createAuthor(transformedData));
    toggle(false);
  };
  const handleError = () => {
    console.log('error');
  };

  return (
    <div className="author-edit-container">
      <div className="author-edit-wrapper">
        <div className="title">
          <h2>{i18n(`manageAuthors.createAuthors.title`)}</h2>
        </div>
        <div className="author-details" style={{ width: '100%' }}>
          <NewBookForm
            schema={schema}
            onHandleSuccess={createAuthors}
            onHandleError={handleError}
            initialValues={initialValues}
          >
            <div className="author-data">
              <InputFormItem
                name="emriPlote"
                placeholder={i18n(`manageAuthors.placeholders.name`)}
              />
              <InputFormItem
                name="ditelindja"
                type="date"
                placeholder={i18n(`manageAuthors.placeholders.birthday`)}
              />
            </div>
            <div className="user-edit-buttons">
              <button
                type="button"
                className="btn-secondary"
                onClick={() => toggle(false)}
              >
                {i18n(`buttons.cancel`)}
              </button>
              <button type="submit" className="btn-primary">
                {i18n(`buttons.createAuthor`)}
              </button>
            </div>
          </NewBookForm>
        </div>
      </div>
    </div>
  );
};
