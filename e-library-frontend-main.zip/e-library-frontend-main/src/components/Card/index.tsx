export { Card as default } from './card';
