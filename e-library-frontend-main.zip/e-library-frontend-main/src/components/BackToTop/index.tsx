export { BackToTop as default } from './backToTop';
