import { i18n } from '../../i18n';

interface SelectOptionsProps {
  id: any;
  value: string;
  label: string;
}
interface ApproveOptions {
  id: any;
  value: boolean;
  label: string;
}

export const bookCategoryOptions: Array<SelectOptionsProps> = [
  {
    id: 1,
    value: 'TEKST_MESIMOR',
    label: i18n(`selectOptions.bookCategory.TEKST_MESIMOR`),
  },
  {
    id: 2,
    value: 'MONOGRAFI',
    label: i18n(`selectOptions.bookCategory.MONOGRAFI`),
  },
  { id: 3, value: 'MANUAL', label: i18n(`selectOptions.bookCategory.MANUAL`) },
  {
    id: 4,
    value: 'CIKEL_LEKSIONESH',
    label: i18n(`selectOptions.bookCategory.CIKEL_LEKSIONESH`),
  },
  {
    id: 5,
    value: 'KOMENTAR',
    label: i18n(`selectOptions.bookCategory.KOMENTAR`),
  },
];
export const magazineCategoryOptions: Array<SelectOptionsProps> = [
  {
    id: 6,
    value: 'REVISTA_PERIODIKE_SHKENCORE',
    label: i18n(`selectOptions.bookCategory.REVISTA_PERIODIKE_SHKENCORE`),
  },
  {
    id: 7,
    value: 'REVISTA_PERIODIKE_PROFESIONALE',
    label: i18n(`selectOptions.bookCategory.REVISTA_PERIODIKE_PROFESIONALE`),
  },
];

export const fieldOptions: Array<SelectOptionsProps> = [
  {
    id: 1,
    value: 'E_DREJTA_PENALE',
    label: i18n(`selectOptions.field.E_DREJTA_PENALE`),
  },
  {
    id: 2,
    value: 'E_DREJTA_CIVILE',
    label: i18n(`selectOptions.field.E_DREJTA_CIVILE`),
  },
  {
    id: 3,
    value: 'E_DREJTA_PUBLIKE',
    label: i18n(`selectOptions.field.E_DREJTA_PUBLIKE`),
  },
  {
    id: 4,
    value: 'PROCUDURE_PENALE',
    label: i18n(`selectOptions.field.PROCUDURE_PENALE`),
  },
  {
    id: 5,
    value: 'PROCEDURE_CIVILE',
    label: i18n(`selectOptions.field.PROCEDURE_CIVILE`),
  },
];

export const typeOptions: Array<SelectOptionsProps> = [
  { id: 1, value: 'LIBER', label: i18n(`selectOptions.type.LIBER`) },
  { id: 2, value: 'PERIODIK', label: i18n(`selectOptions.type.PERIODIK`) },
];

export const userRoleOptions: Array<SelectOptionsProps> = [
  { id: 1, value: 'ADMIN', label: i18n(`selectOptions.userRole.ADMIN`) },
  { id: 2, value: 'MENAXHER', label: i18n(`selectOptions.userRole.MENAXHER`) },
  {
    id: 3,
    value: 'PERDORUES',
    label: i18n(`selectOptions.userRole.PERDORUES`),
  },
];

export const userTypeOptions: Array<SelectOptionsProps> = [
  { id: 1, value: 'GJYQTAR', label: i18n(`selectOptions.userType.GJYQTAR`) },
  { id: 2, value: 'PROKUROR', label: i18n(`selectOptions.userType.PROKUROR`) },
  { id: 3, value: 'STUDENT', label: i18n(`selectOptions.userType.STUDENT`) },
  {
    id: 4,
    value: 'KANDIDAT_MAGJISTRATE',
    label: i18n(`selectOptions.userType.KANDIDAT_MAGJISTRATE`),
  },
  {
    id: 5,
    value: 'KANDIDAT_KESHILLTAR',
    label: i18n(`selectOptions.userType.KANDIDAT_KESHILLTAR`),
  },
  {
    id: 6,
    value: 'KANDIDAT_KANCELAR',
    label: i18n(`selectOptions.userType.KANDIDAT_KANCELAR`),
  },
  {
    id: 7,
    value: 'KANDIDAT_AVOKAT_SHTETI',
    label: i18n(`selectOptions.userType.KANDIDAT_AVOKAT_SHTETI`),
  },
  {
    id: 8,
    value: 'AVOKAT_SHTETI',
    label: i18n(`selectOptions.userType.AVOKAT_SHTETI`),
  },
  { id: 9, value: 'KANCELAR', label: i18n(`selectOptions.userType.KANCELAR`) },
  {
    id: 10,
    value: 'KESHILLTAR_LIGJOR',
    label: i18n(`selectOptions.userType.KESHILLTAR_LIGJOR`),
  },
  {
    id: 11,
    value: 'NDIHMES_LIGJOR',
    label: i18n(`selectOptions.userType.NDIHMES_LIGJOR`),
  },
  {
    id: 12,
    value: 'ADMINISTRATE',
    label: i18n(`selectOptions.userType.ADMINISTRATE`),
  },
  { id: 13, value: 'PEDAGOGE', label: i18n(`selectOptions.userType.PEDAGOGE`) },
  { id: 14, value: 'EKSPERTE', label: i18n(`selectOptions.userType.EKSPERTE`) },
];

export const userApproveOptions: Array<ApproveOptions> = [
  { id: 1, value: true, label: i18n(`selectOptions.approved.true`) },
  { id: 2, value: false, label: i18n(`selectOptions.approved.false`) },
];
export const PayTypes: Array<SelectOptionsProps> = [
  { id: 1, value: 'po', label: i18n(`filters.withPay`) },
  { id: 2, value: 'jo', label: i18n(`filters.free`) },
];
