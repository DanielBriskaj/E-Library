export { UploadBookMaterials as default } from './uploadBookMaterials';
