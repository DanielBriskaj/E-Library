export { Footer as default } from './footer';
