export { HomeBanner as default } from './Banner';
