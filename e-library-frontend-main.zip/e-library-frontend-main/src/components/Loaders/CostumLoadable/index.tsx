export { CustomLoadable as default } from './CostumLoadable';
