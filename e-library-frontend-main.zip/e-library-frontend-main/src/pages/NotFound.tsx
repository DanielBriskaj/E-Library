import React from 'react';
import { useNavigate } from 'react-router-dom';
import NotFoundIcon from '../assets/images/404.png';
import { i18n } from '../i18n';
const NotFound = () => {
  const navigate = useNavigate();

  return (
    <div className="forbiden-page">
      <span className="fobiden-title">
        <img src={NotFoundIcon} alt="" /> <h1>Error 404 - Page Not Found</h1>
      </span>
      <hr />
      <div className="forbiden-content">
        <span>
          <button className="btn-primary" onClick={e => navigate('/')}>
            Home
          </button>
        </span>
      </div>
    </div>
  );
};

export default NotFound;
