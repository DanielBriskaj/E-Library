import React, { useEffect, useState } from 'react';
import Card from '../../components/Card';
import { useNavigate } from 'react-router-dom';
import { ReactComponent as RightArrow } from '../../assets/svgIcons/right-arrow.svg';
import { useDispatch, useSelector } from 'react-redux';
import {
  selectBooks,
  selectLoading,
  fetchHomePageData,
  selectHomePageData,
} from '../../redux/slices/Books/booksSlice';
import HomeBanner from '../../components/HomePageBanner';
import { i18n } from '../../i18n';

interface HomeProps {
  children: any;
}
export const Home: React.FunctionComponent<HomeProps> = () => {
  const dispatch = useDispatch();
  const booksState = useSelector(selectBooks);
  const homeData = useSelector(selectHomePageData);
  const loading = useSelector(selectLoading);
  const [bookHover, setbookHover] = useState(false);
  const [revistHover, setRevistHover] = useState(false);
  const navigate = useNavigate();

  const { innerWidth: width, innerHeight: height } = window;
  const [reqNumber, setReqNumber] = useState<number>();

  useEffect(() => {
    if (width < 1450 && width > 1200) {
      setReqNumber(4);
    } else if (width < 1200 && width > 900) {
      setReqNumber(3);
    } else {
      setReqNumber(5);
    }
    reqNumber &&
      dispatch(
        fetchHomePageData({
          type: 'revist',
          query: { lloji: 'PERIODIK', numri: reqNumber },
        }),
      );
    reqNumber &&
      dispatch(
        fetchHomePageData({
          type: 'liber',
          query: { lloji: 'LIBER', numri: reqNumber },
        }),
      );
  }, [reqNumber]);

  return (
    <main className="home-container">
      <div className="home-wrapper">
        <HomeBanner />
        <div className="books">
          <div className="home-section-header">
            <h2>{i18n(`navbar.main.books`)}</h2>
            <span
              onClick={() => navigate('/books')}
              onMouseEnter={() => setbookHover(true)}
              onMouseLeave={() => setbookHover(false)}
            >
              {i18n(`home.viewAll`)}
              <RightArrow
                style={bookHover ? { fill: 'white' } : { fill: '#272e6e' }}
                className="right-arrow"
              />
            </span>
          </div>
          {homeData.homeBooks.length !== 0 ? (
            <div className="books-section">
              {booksState.loading
                ? 'Loading...'
                : homeData.homeBooks.map((data, index) => {
                    const props = {
                      id: data.id,
                      title: data.emri,
                      image: data.imgUrl,
                      favorite: data.favorite,
                      category: data.kategoriaList,
                      page_nr: data.nrFaqeve,
                      authors: data.autoreTeLibrave,
                      userProgress: (data.faqeTeLexuara / data.nrFaqeve) * 100,
                    };
                    return <Card key={index} {...props} />;
                  })}
            </div>
          ) : !loading && homeData.homeBooks.length === 0 ? (
            <span style={{ width: '100%' }}>{i18n(`noData`)}</span>
          ) : (
            'Loading...'
          )}
        </div>
        <div className="resvists">
          <div className="home-section-header">
            <h2>{i18n(`navbar.main.periodic`)}</h2>
            <span
              onClick={() => navigate('/magazines')}
              onMouseEnter={() => setRevistHover(true)}
              onMouseLeave={() => setRevistHover(false)}
            >
              {i18n(`home.viewAll`)}
              <RightArrow
                style={revistHover ? { fill: 'white' } : { fill: '#272e6e' }}
                className="right-arrow"
              />
            </span>
          </div>
          {homeData.homeRevist.length !== 0 ? (
            <div className="books-section">
              {booksState.loading
                ? 'Loading...'
                : homeData.homeRevist.map((data, index) => {
                    const props = {
                      id: data.id,
                      title: data.emri,
                      image: data.imgUrl,
                      favorite: data.favorite,
                      category: data.kategoriaList,
                      page_nr: data.nrFaqeve,
                      authors: data.autoreTeLibrave,
                      userProgress: (data.faqeTeLexuara / data.nrFaqeve) * 100,
                    };
                    return <Card key={index} {...props} />;
                  })}
            </div>
          ) : !loading && homeData.homeRevist.length === 0 ? (
            <span style={{ width: '100%' }}>{i18n(`noData`)}</span>
          ) : (
            'Loading...'
          )}
        </div>
      </div>
    </main>
  );
};
