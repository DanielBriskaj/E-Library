import React, { useEffect, useState } from 'react';
import InputFormItem from '../../components/InputFormItem';
import TextAreaFormItem from '../../components/TextAreaFormItem';
import UploadBookCover from '../../components/UploadBookCover';
import UploadBook from '../../components/UploadBookMaterials';
import { ReactComponent as BackArrowSvg } from '../../assets/svgIcons/back-arrow-svg.svg';
import { ReactComponent as Spinner } from '../../assets/svgIcons/spinner.svg';
import NewBookForm from '../../components/NewBookForm';
import * as yup from 'yup';
import SingleSelectFormItem from '../../components/SingleSelectFormItem';
import MultiSelectFormItem from '../../components/MultiSelectFormItem';
import {
  bookCategoryOptions,
  magazineCategoryOptions,
  fieldOptions,
  typeOptions,
} from '../../components/SelectOptions/selectFieldOptions';
import createBookDataTransformer from '../../helpers/crateBook/createCourseDataTransformer';
import { useDispatch, useSelector } from 'react-redux';
import {
  resetBooksState,
  updateBookData,
  deleteBook,
  selectSuccess,
  selectLoading,
} from '../../redux/slices/Books/booksSlice';
import {
  selectAuthors,
  fetchAuthors,
} from '../../redux/slices/Authors/authorsSlice';
import authorsDataTransformer from '../../helpers/crateBook/authorsDataTransformer';
import { useNavigate, useParams } from 'react-router';
import {
  fetchSingleBook,
  selectSingleBook,
} from '../../redux/slices/Books/singleBookSlice';
import categoryDataTransformer from '../../helpers/crateBook/categoryDataTransformer';
import fieldDataTransformer from '../../helpers/crateBook/fieldDataTransformer';
import { CheckBoxItem } from '../../components/CheckBoxInput';
import DeleteWindow from '../../components/DeleteWindow';
import { i18n } from '../../i18n';
interface SelectOptionsProps {
  id?: any;
  value?: string;
  label?: string;
}
interface EditBooksProps {
  children: any;
}

export const EditBooks: React.FunctionComponent<EditBooksProps> = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { id } = useParams();

  useEffect(() => {
    dispatch(resetBooksState());
    dispatch(fetchAuthors(''));
    dispatch(fetchSingleBook(id));
  }, []);

  const authors = useSelector(selectAuthors);
  const { singleBook, singleBookLoading } = useSelector(selectSingleBook);

  const schema = yup.object().shape({
    emri: yup.string().max(250).nullable().required(i18n(`bookErrors.name`)),
    pershkrimi: yup
      .string()
      .nullable()
      .required(i18n(`bookErrors.description`)),
    autoreTeLibrave: yup
      .array()
      .nullable()
      .required(i18n(`bookErrors.authors`)),
    lloji: yup.string().nullable().required(i18n(`bookErrors.type`)),
    kategoriaList: yup.array().nullable().required(i18n(`bookErrors.category`)),
    fushaList: yup.array().nullable().required(i18n(`bookErrors.field`)),
    dataPublikimit: yup
      .date()
      .nullable()
      .min('1900-01-01', i18n(`bookErrors.publishDate.minMax`))
      .max(new Date(), i18n(`bookErrors.publishDate.minMax`))
      .required(i18n(`bookErrors.publishDate.required`)),
    nrFaqeve: yup
      .number()
      .nullable()
      .positive()
      .typeError(i18n(`bookErrors.pageNr.required`))
      .min(1, i18n(`bookErrors.pageNr.min`))
      .required(i18n(`bookErrors.pageNr.required`)),
    kodiISBN: yup.string().nullable().required(i18n(`bookErrors.isbnCode`)),
    cmimi: yup
      .number()
      .positive()
      .typeError(i18n(`bookErrors.price.required`))
      .when('mePagese', {
        is: true,
        then: yup.number().nullable().min(1, i18n(`bookErrors.price.min`)),
        otherwise: yup.number().nullable().min(0, i18n(`bookErrors.price.min`)),
      })
      .required(i18n(`bookErrors.price.required`)),
    mePagese: yup.boolean().nullable(),
    file: yup.mixed().required(i18n(`bookErrors.file`)),
    image: yup.mixed(),
  });

  const [initalValues, setInitialValues] = useState<any>(null);
  const [bookType, setBookType] = useState<any>(null);

  useEffect(() => {
    if (singleBook) {
      setInitialValues({
        image: singleBook?.imgUrl,
        emri: singleBook?.emri,
        pershkrimi: singleBook?.pershkrimi,
        autoreTeLibrave: authorsDataTransformer(singleBook.autoreTeLibrave),
        kategoriaList: categoryDataTransformer(singleBook.kategoriaList),
        fushaList: fieldDataTransformer(singleBook.fushaList),
        lloji: singleBook?.lloji,
        dataPublikimit: singleBook?.dataPublikimit,
        nrFaqeve: singleBook?.nrFaqeve,
        kodiISBN: singleBook?.kodiISBN,
        cmimi: singleBook?.cmimi,
        mePagese: singleBook?.mePagese,
        file: singleBook?.fileUrl,
      });
    }
  }, [singleBook]);

  const onHandleSuccess = (data: any) => {
    const transformedData = createBookDataTransformer(data);
    dispatch(
      updateBookData({ data: transformedData.bookData, id: Number(id) }),
    );
  };
  const onHandleError = () => {
    console.log('Error occured while adding a new book!');
  };
  const createdSuccess = useSelector(selectSuccess);
  const loading = useSelector(selectLoading);

  useEffect(() => {
    if (createdSuccess) {
      navigate('/');
      dispatch(resetBooksState());
    }
  }, [createdSuccess]);
  const handleDeleteBook = () => {
    dispatch(deleteBook(Number(id)));
    navigate(-1);
  };

  const [categoryOptions, setcategoryOptions] =
    useState<Array<SelectOptionsProps>>();

  useEffect(() => {
    if (initalValues) {
      if (initalValues.lloji === 'LIBER') {
        setcategoryOptions(bookCategoryOptions);
      } else if (initalValues.lloji === 'PERIODIK') {
        setcategoryOptions(magazineCategoryOptions);
      }
    }
  }, [initalValues]);

  const value = (options: any, value: any) => {
    if (value != null) {
      return options.find((option: any) => option.value === value);
    }
    return null;
  };

  return (
    <>
      {initalValues ? (
        <NewBookForm
          schema={schema}
          initialValues={initalValues}
          onHandleSuccess={onHandleSuccess}
          onHandleError={onHandleError}
        >
          <main className="create-books-main">
            <div className="wrapper">
              <div className="title">
                <BackArrowSvg
                  className="back-arrow"
                  onClick={() => navigate(-1)}
                  fill="#3f78e0"
                />
                <h2>{i18n(`createBooksPage.editHeader`)}</h2>
              </div>
              <div className="container">
                <UploadBookCover name="image" image={singleBook?.imgUrl} />
                <InputFormItem
                  name="emri"
                  label={i18n(`createBooksPage.placeholders.name`)}
                  placeholder={i18n(`createBooksPage.placeholders.name`)}
                  value={initalValues.emri}
                />
                <TextAreaFormItem
                  name="pershkrimi"
                  label={i18n(`createBooksPage.placeholders.description`)}
                  placeholder={i18n(`createBooksPage.placeholders.description`)}
                  value={initalValues.pershkrimi}
                />
                <MultiSelectFormItem
                  name="autoreTeLibrave"
                  label={i18n(`createBooksPage.placeholders.author`)}
                  placeholder={i18n(`createBooksPage.placeholders.author`)}
                  selectValue={initalValues.autoreTeLibrave}
                  options={authorsDataTransformer(authors.authors)}
                  onChange={(e: any) => {
                    setInitialValues((oldInitialValues: any) => {
                      return {
                        ...oldInitialValues,
                        autoreTeLibrave: e.length > 0 ? e : null,
                      };
                    });
                  }}
                />
                <div className="row-space-between">
                  <SingleSelectFormItem
                    name="lloji"
                    initialValue={initalValues.lloji}
                    contolledValue={value(typeOptions, initalValues?.lloji)}
                    placeholder={i18n(`createBooksPage.placeholders.type`)}
                    options={typeOptions}
                    onChange={(e: any) => {
                      setInitialValues((oldInitialValues: any) => {
                        return {
                          ...oldInitialValues,
                          kategoriaList: null,
                          lloji: e.value,
                        };
                      });
                      setBookType(e.value);
                    }}
                  />
                  <MultiSelectFormItem
                    name="kategoriaList"
                    placeholder={i18n(`createBooksPage.placeholders.category`)}
                    selectValue={initalValues?.kategoriaList}
                    disabled={initalValues.lloji ? false : true}
                    options={categoryOptions && categoryOptions}
                    onChange={(e: any) => {
                      setInitialValues((oldInitialValues: any) => {
                        return {
                          ...oldInitialValues,
                          kategoriaList: e,
                        };
                      });
                    }}
                  />
                </div>
                <div className="row-space-between">
                  <MultiSelectFormItem
                    name="fushaList"
                    placeholder={i18n(`createBooksPage.placeholders.field`)}
                    selectValue={initalValues?.fushaList}
                    options={fieldOptions}
                    onChange={(e: any) => {
                      setInitialValues((oldInitialValues: any) => {
                        return {
                          ...oldInitialValues,
                          fushaList: e,
                        };
                      });
                    }}
                  />
                  <InputFormItem
                    name="kodiISBN"
                    label={i18n(`createBooksPage.placeholders.isbnCode`)}
                    placeholder={i18n(`createBooksPage.placeholders.isbnCode`)}
                    className="two-inputs"
                    value={initalValues.kodiISBN}
                  />
                </div>
                <div className="row-space-between">
                  <InputFormItem
                    name="dataPublikimit"
                    label={i18n(`createBooksPage.placeholders.publishDate`)}
                    placeholder={i18n(
                      `createBooksPage.placeholders.publishDate`,
                    )}
                    type="date"
                    className="two-inputs"
                    value={initalValues.dataPublikimit}
                    style={{ height: '42px' }}
                  />
                  <InputFormItem
                    name="nrFaqeve"
                    label={i18n(`createBooksPage.placeholders.pageNr`)}
                    placeholder={i18n(`createBooksPage.placeholders.pageNr`)}
                    type="number"
                    className="two-inputs"
                    value={initalValues.nrFaqeve}
                  />
                </div>
                <div className="row-space-between">
                  <InputFormItem
                    name="cmimi"
                    label={i18n(`createBooksPage.placeholders.price`)}
                    placeholder={i18n(`createBooksPage.placeholders.price`)}
                    type="number"
                    className="two-inputs"
                    value={initalValues.cmimi}
                  />
                  <CheckBoxItem
                    name="mePagese"
                    label={i18n(`createBooksPage.placeholders.pay`)}
                    className="two-inputs"
                    checked={initalValues.mePagese}
                  />
                </div>

                <UploadBook name="file" fileName={singleBook?.filename} />
                <div className="row-stack">
                  <button
                    type="submit"
                    className="btn-primary"
                    disabled={loading}
                  >
                    {i18n(`buttons.saveBook`)}
                  </button>
                  <DeleteWindow deleteBook={handleDeleteBook} />
                </div>
              </div>
            </div>
          </main>
        </NewBookForm>
      ) : (
        <div className="loader">
          <Spinner className="spinner load-spin" />
        </div>
      )}
    </>
  );
};
