export { MyLibrary as default } from './myLibrary';
