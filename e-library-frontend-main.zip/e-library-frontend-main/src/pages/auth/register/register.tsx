import React, { useEffect, useState } from 'react';
import InputFormItem from '../../../components/InputFormItem';
import NewBookForm from '../../../components/NewBookForm';
import * as yup from 'yup';
import { ReactComponent as LoginArrow } from '../../../assets/svgIcons/box-arrow-in-right.svg';
import { ReactComponent as Spinner } from '../../../assets/svgIcons/spinner.svg';
import { ReactComponent as Eye } from '../../../assets/svgIcons/eye.svg';
import { ReactComponent as EyeSlash } from '../../../assets/svgIcons/eye-slash.svg';
import Button from '../../../components/Button';
import { useDispatch, useSelector } from 'react-redux';
import {
  userRegister,
  selectLoading,
  selectAuth,
  selectErrorMessage,
  resetRegisterState,
} from '../../../redux/slices/AUTH/Register/registerSlice';
import { useForm } from 'react-hook-form';
import { ReactComponent as Alert } from '../../../assets/svgIcons/error-svg.svg';
import { useNavigate } from 'react-router';
import { i18n } from '../../../i18n';
import { CheckBoxItem } from '../../../components/CheckBoxInput';
import notificationThrower from '../../../helpers/notificationThrower';

export const Register: React.FunctionComponent = () => {
  const dispatch = useDispatch();
  const loading = useSelector(selectLoading);
  const auth = useSelector(selectAuth);
  const error = useSelector(selectErrorMessage);
  const navigate = useNavigate();

  const schema = yup.object().shape({
    emri: yup
      .string()
      .nullable()
      .matches(/^[A-Za-z ]*$/, i18n(`userErrors.name.matches`))
      .matches(/^\S+$/, i18n(`userErrors.name.spaces`))
      .max(250, i18n(`userErrors.name.max`))
      .required(i18n(`userErrors.name.required`)),
    mbiemri: yup
      .string()
      .nullable()
      .matches(/^\S+$/, i18n(`userErrors.lastName.spaces`))
      .matches(/^[A-Za-z ]*$/, i18n(`userErrors.lastName.matches`))
      .max(250, i18n(`userErrors.lastName.max`))
      .required(i18n(`userErrors.lastName.required`)),
    email: yup
      .string()
      .nullable()
      .matches(/^\S+$/, i18n(`userErrors.email.matches`))
      .email(i18n(`userErrors.email.emailType`))
      .required(i18n(`userErrors.email.required`)),
    username: yup
      .string()
      .nullable()
      .min(4, i18n(`userErrors.username.min`))
      .matches(/^\S+$/, i18n(`userErrors.username.matches`))
      .max(20, i18n(`userErrors.username.max`))
      .required(i18n(`userErrors.username.required`)),
    password: yup
      .string()
      .nullable()
      .min(4, i18n(`userErrors.password.min`))
      .max(250, i18n(`userErrors.password.max`))
      .required(i18n(`userErrors.password.required`)),
    confirmPassword: yup
      .string()
      .oneOf(
        [yup.ref('password'), null],
        i18n(`userErrors.confirmPassword.matches`),
      )
      .required(i18n(`userErrors.confirmPassword.required`)),
    termsAndConditions: yup
      .boolean()
      .default(false)
      .oneOf([true], i18n(`userErrors.termsAndConditions`)),
  });
  const { reset } = useForm();
  const [initialValues] = useState(() => {
    return {
      emri: null,
      mbiemri: null,
      email: null,
      username: null,
      password: null,
      aprovuar: false,
    };
  });
  const onHandleError = () => {
    console.log('Error while trying to register');
  };
  const onHandleSuccess = (data: any) => {
    dispatch(userRegister(data));
    reset();
  };
  const [viewPass, setViewPass] = useState(false);

  useEffect(() => {
    if (auth) {
      navigate('/');
      dispatch(resetRegisterState());
    }
  }, [auth]);
  return (
    <NewBookForm
      schema={schema}
      initialValues={initialValues}
      onHandleError={onHandleError}
      onHandleSuccess={onHandleSuccess}
    >
      <div className="register-wrapper">
        <div className="register-container">
          <h2>{i18n(`registerPage.title`)}</h2>
          {error && (
            <div className="error">
              {' '}
              <Alert fill="red" className="error-svg" />
              {i18n(`registerPage.${error}`)}
            </div>
          )}
          <InputFormItem placeholder={i18n(`userData.name`)} name="emri" />
          <InputFormItem
            placeholder={i18n(`userData.lastName`)}
            name="mbiemri"
          />
          <InputFormItem
            placeholder={i18n(`userData.username`)}
            name="username"
          />
          <InputFormItem placeholder={i18n(`userData.email`)} name="email" />
          <div className="password-container">
            <InputFormItem
              placeholder={i18n(`userData.password`)}
              name="password"
              type={viewPass === true ? 'text' : 'password'}
            />
            {viewPass === true ? (
              <EyeSlash
                className="eye-svg"
                onClick={() => setViewPass(!viewPass)}
              />
            ) : (
              <Eye className="eye-svg" onClick={() => setViewPass(!viewPass)} />
            )}
          </div>
          <div className="password-container">
            <InputFormItem
              placeholder={i18n(`userData.verifyPassword`)}
              name="confirmPassword"
              type={viewPass === true ? 'text' : 'password'}
            />
            {viewPass === true ? (
              <EyeSlash
                className="eye-svg"
                onClick={() => setViewPass(!viewPass)}
              />
            ) : (
              <Eye className="eye-svg" onClick={() => setViewPass(!viewPass)} />
            )}
          </div>
          <Button type="submit" className="btn-login">
            {loading === true ? (
              <Spinner className="spinner" width="15px" height="15px" />
            ) : (
              <LoginArrow className="login-arrow" />
            )}
            {i18n(`buttons.register`)}
          </Button>
          <div className="terms">
            <CheckBoxItem name="termsAndConditions" />
            <span>
              {i18n(`registerPage.terms.accept`)}
              <a
                href="/terms-and-conditions"
                target="_blank"
                style={{
                  cursor: 'pointer',
                  color: '#3f78e0',
                  textDecoration: 'none',
                }}
              >
                {i18n(`registerPage.terms.condition`)}
              </a>
              {i18n(`registerPage.terms.library`)}
            </span>
          </div>
          <div style={{ marginTop: '10px' }}>
            {i18n(`registerPage.haveAccount`)}
            <span
              style={{ cursor: 'pointer', color: '#3f78e0' }}
              onClick={() => navigate('/login')}
            >
              {i18n(`loginPage.title`)}
            </span>
          </div>
        </div>
      </div>
    </NewBookForm>
  );
};
