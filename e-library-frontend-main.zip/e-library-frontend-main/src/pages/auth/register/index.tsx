export { Register as default } from './register';
