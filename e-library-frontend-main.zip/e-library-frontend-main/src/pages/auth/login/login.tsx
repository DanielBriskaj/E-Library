import React, { useState, useEffect } from 'react';
import InputFormItem from '../../../components/InputFormItem';
import NewBookForm from '../../../components/NewBookForm';
import * as yup from 'yup';
import { ReactComponent as LoginArrow } from '../../../assets/svgIcons/box-arrow-in-right.svg';
import { ReactComponent as Spinner } from '../../../assets/svgIcons/spinner.svg';
import { ReactComponent as Alert } from '../../../assets/svgIcons/error-svg.svg';
import { ReactComponent as Eye } from '../../../assets/svgIcons/eye.svg';
import { ReactComponent as EyeSlash } from '../../../assets/svgIcons/eye-slash.svg';
import Button from '../../../components/Button';
import { useDispatch, useSelector } from 'react-redux';
import {
  userLogin,
  selectLoading,
  selectAuth,
  selectErrorMessage,
} from '../../../redux/slices/AUTH/Login/loginSlice';
import { resetBooksState } from '../../../redux/slices/Books/booksSlice';
import { useNavigate } from 'react-router';
import { i18n } from '../../../i18n';

export const Login: React.FunctionComponent = () => {
  const dispatch = useDispatch();
  const loading = useSelector(selectLoading);
  const auth = useSelector(selectAuth);
  const error = useSelector(selectErrorMessage);
  const navigate = useNavigate();

  const schema = yup.object().shape({
    email: yup
      .string()
      .nullable()
      .matches(/^\S+$/, i18n(`userErrors.email.matches`))
      .email(i18n(`userErrors.email.emailType`))
      .required(i18n(`userErrors.email.required`)),
    password: yup
      .string()
      .nullable()
      .min(4, i18n(`userErrors.password.min`))
      .max(250, i18n(`userErrors.password.max`))
      .required(i18n(`userErrors.password.required`)),
  });
  const [initialValues] = useState(() => {
    return {
      email: null,
      password: null,
    };
  });
  const onHandleError = () => {
    console.log('Error while trying to login');
  };
  const onHandleSuccess = (data: any) => {
    dispatch(userLogin(data));
  };

  useEffect(() => {
    if (auth && !error) {
      dispatch(resetBooksState());
      navigate('/');
    }
  }, [loading]);

  const [viewPass, setViewPass] = useState(false);

  return (
    <NewBookForm
      schema={schema}
      initialValues={initialValues}
      onHandleError={onHandleError}
      onHandleSuccess={onHandleSuccess}
    >
      <div className="login-wrapper">
        <div className="login-container">
          <h2>{i18n(`loginPage.title`)}</h2>
          {auth === true ? (
            <div className="successful">{i18n(`loginPage.success`)}</div>
          ) : (
            ''
          )}
          {error && (
            <div className="error">
              {' '}
              <Alert fill="red" className="error-svg" />
              {i18n(`loginPage.${error}`)}
            </div>
          )}
          <InputFormItem placeholder={i18n(`userData.email`)} name="email" />
          <div className="password-container">
            <InputFormItem
              placeholder={i18n(`userData.password`)}
              name="password"
              type={viewPass === true ? 'text' : 'password'}
            />
            {viewPass === true ? (
              <EyeSlash
                className="eye-svg"
                onClick={() => setViewPass(!viewPass)}
              />
            ) : (
              <Eye className="eye-svg" onClick={() => setViewPass(!viewPass)} />
            )}
          </div>
          <Button type="submit" className="btn-login">
            {loading === true ? (
              <Spinner className="spinner" width="15px" height="15px" />
            ) : (
              <LoginArrow className="login-arrow" />
            )}
            {i18n(`buttons.login`)}
          </Button>
          <div>
            {i18n(`loginPage.noAccount`)}
            <span
              style={{ cursor: 'pointer', color: '#3f78e0' }}
              onClick={() => navigate('/register')}
            >
              {i18n(`registerPage.title`)}
            </span>
          </div>
        </div>
      </div>
    </NewBookForm>
  );
};
