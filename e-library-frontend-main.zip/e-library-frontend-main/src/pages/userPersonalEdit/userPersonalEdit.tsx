import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  getLoggedUser,
  loggedUserId,
  resetLoggedState,
} from '../../redux/slices/AUTH/Login/loginSlice';
import {
  fetchSingleUser,
  resetUserState,
  selectSingleUser,
  selectSingleUserLoading,
  updateSingleUser,
} from '../../redux/slices/Users/usersSlice';
import { ReactComponent as Spinner } from '../../assets/svgIcons/spinner.svg';
import { ReactComponent as BackArrow } from '../../assets/svgIcons/back-arrow-svg.svg';
import InputFormItem from '../../components/InputFormItem';
import NewBookForm from '../../components/NewBookForm';
import * as yup from 'yup';
import { userInfoDataTransformer } from '../../helpers/editUser/userRoleDataTransformer';
import { useNavigate } from 'react-router';
import { i18n } from '../../i18n';
import ChangePassword from '../../components/PasswordPopUp';

export const UserPersonalEdit: React.FunctionComponent = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const userId = useSelector(loggedUserId);
  const user = useSelector(selectSingleUser);
  const loading = useSelector(selectSingleUserLoading);
  const [initialValues, setInitialValues] = useState<any>(null);
  const [editProfile, setEditProfile] = useState(true);
  const [changePass, setChangePass] = useState(false);
  const schema = yup.object().shape({
    emri: yup
      .string()
      .matches(/^[A-Za-z ]*$/, i18n(`userErrors.name.matches`))
      .matches(/^\S+$/, i18n(`userErrors.name.spaces`))
      .max(250, i18n(`userErrors.name.max`))
      .required(i18n(`userErrors.name.required`)),
    mbiemri: yup
      .string()
      .matches(/^\S+$/, i18n(`userErrors.lastName.spaces`))
      .matches(/^[A-Za-z ]*$/, i18n(`userErrors.lastName.matches`))
      .max(250, i18n(`userErrors.lastName.max`))
      .required(i18n(`userErrors.lastName.required`)),
    username: yup
      .string()
      .nullable()
      .min(4, i18n(`userErrors.username.min`))
      .matches(/^\S+$/, i18n(`userErrors.username.matches`))
      .max(20, i18n(`userErrors.username.max`))
      .required(i18n(`userErrors.username.required`)),
  });
  useEffect(() => {
    if (userId) {
      dispatch(fetchSingleUser(Number(userId.id)));
    }
  }, [userId]);

  useEffect(() => {
    dispatch(resetUserState());
    if (user) {
      setInitialValues(() => {
        return {
          id: user?.id,
          emri: user?.emri,
          mbiemri: user?.mbiemri,
          email: user?.email,
          username: user?.username,
        };
      });
    }
  }, [user]);
  const handleUserEdit = (data: any) => {
    const transformedData = userInfoDataTransformer(data);
    dispatch(
      updateSingleUser({ data: transformedData, id: Number(initialValues.id) }),
    );
    setEditProfile(!editProfile);
  };
  const onHandleError = () => {
    console.log('error');
  };
  return (
    <>
      {initialValues ? (
        <div className="account-container">
          <div className="account-wrapper">
            <div className="account-header">
              <div className="account-title">
                <span onClick={() => navigate(-1)}>
                  <BackArrow fill="#3f78e0" className="back-arrow-svg" />
                </span>
                <h2>{i18n(`pages.myProfile`)}</h2>
              </div>
              <div className="edit-profile-buttons">
                <button
                  type="button"
                  onClick={() => setEditProfile(!editProfile)}
                  disabled={loading}
                  className="btn-primary"
                >
                  {i18n(`buttons.changeProfile`)}
                </button>
                <button
                  type="button"
                  onClick={() => setChangePass(!changePass)}
                  disabled={loading}
                  className="btn-primary"
                >
                  {i18n(`buttons.changePassword`)}
                </button>
              </div>
              {changePass && <ChangePassword toggle={setChangePass} />}
            </div>
            <NewBookForm
              onHandleSuccess={handleUserEdit}
              onHandleError={onHandleError}
              initialValues={initialValues}
              schema={schema}
            >
              <div className="account-info-container">
                <InputFormItem
                  name="emri"
                  placeholder={i18n(`userData.name`)}
                  value={initialValues?.emri}
                  disabled={editProfile}
                />
                <InputFormItem
                  name="mbiemri"
                  placeholder={i18n(`userData.lastName`)}
                  value={initialValues?.mbiemri}
                  disabled={editProfile}
                />
                <InputFormItem
                  name="username"
                  placeholder={i18n(`userData.username`)}
                  value={initialValues?.username}
                  disabled={editProfile}
                />
                <InputFormItem
                  name="email"
                  placeholder={i18n(`userData.email`)}
                  value={initialValues?.email}
                  disabled={true}
                />
                {editProfile ? (
                  ''
                ) : (
                  <div className="edit-profile-buttons">
                    <button
                      type="button"
                      className="btn-secondary"
                      onClick={() => setEditProfile(!editProfile)}
                    >
                      {i18n(`buttons.cancel`)}
                    </button>
                    <button
                      type="submit"
                      className="btn-primary"
                      disabled={loading}
                    >
                      {i18n(`buttons.saveChanges`)}
                    </button>
                  </div>
                )}
              </div>
            </NewBookForm>
          </div>
        </div>
      ) : (
        <div className="loader">
          <Spinner className="spinner load-spin" />
        </div>
      )}
    </>
  );
};
