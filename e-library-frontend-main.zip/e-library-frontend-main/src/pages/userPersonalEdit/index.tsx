export { UserPersonalEdit as default } from './userPersonalEdit';
