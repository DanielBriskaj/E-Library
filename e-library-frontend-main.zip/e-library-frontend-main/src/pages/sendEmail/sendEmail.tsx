import React, { useEffect, useState } from 'react';
import InputFormItem from '../../components/InputFormItem';
import NewBookForm from '../../components/NewBookForm';
import * as yup from 'yup';
import { i18n } from '../../i18n';
import SingleSelectFormItem from '../../components/SingleSelectFormItem';
import { userTypeOptions } from '../../components/SelectOptions/selectFieldOptions';
import { ReactComponent as BackArrowSvg } from '../../assets/svgIcons/back-arrow-svg.svg';
import { useNavigate } from 'react-router';
import { useDispatch, useSelector } from 'react-redux';
import {
  selectLoading,
  selectSentEmail,
  sendEmail,
} from '../../redux/slices/Users/usersSlice';
import TextAreaFormItem from '../../components/TextAreaFormItem';

export const SendEmail: React.FunctionComponent = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const schema = yup.object().shape({
    pershkrimi: yup
      .string()
      .nullable()
      .required(i18n(`sendEmail.errors.subject`)),
    url: yup.string().nullable().required(i18n(`sendEmail.errors.body`)),
    tipPerdorues: yup
      .string()
      .nullable()
      .required(i18n(`sendEmail.errors.mailTo`)),
  });
  const handleSendEmail = (data: any) => {
    dispatch(sendEmail(data));
  };
  const handleError = () => {
    console.log('error');
  };
  const emailSent = useSelector(selectSentEmail);
  const loading = useSelector(selectLoading);
  useEffect(() => {
    if (emailSent) {
      navigate('/');
    }
  }, [emailSent]);
  const [initialValues] = useState(() => {
    return {
      pershkrimi: null,
      url: null,
      tipPerdorues: null,
    };
  });
  return (
    <NewBookForm
      schema={schema}
      onHandleSuccess={handleSendEmail}
      onHandleError={handleError}
      initialValues={initialValues}
    >
      <div className="send-email-container">
        <div className="title">
          <BackArrowSvg
            className="back-arrow"
            onClick={() => navigate(-1)}
            fill="#3f78e0"
          />
          <h2>{i18n(`sendEmail.title`)}</h2>
        </div>

        <div className="send-email-wrapper">
          <TextAreaFormItem
            name="pershkrimi"
            placeholder={i18n(`sendEmail.placeholders.subject`)}
          />
          <InputFormItem
            name="url"
            placeholder={i18n(`sendEmail.placeholders.body`)}
          />
          <SingleSelectFormItem
            name="tipPerdorues"
            placeholder={i18n(`sendEmail.placeholders.mailTo`)}
            options={userTypeOptions}
          />
          <button className="btn-primary" disabled={loading}>
            {i18n(`buttons.send`)}
          </button>
        </div>
      </div>
    </NewBookForm>
  );
};
