export { SendEmail as default } from './sendEmail';
