import React, { useState, useEffect, useRef } from 'react';
import { useParams } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';

import {
  fetchSingleBook,
  selectSingleBook,
  selectSingleBookLoading,
} from '../../redux/slices/Books/singleBookSlice';
import {
  saveInLibraria,
  removeFromLibraria,
} from '../../redux/slices/Books/singleBookSlice';
import { updateBookProgres } from '../../redux/slices/Books/booksSlice';

import notificationThrower from '../../helpers/notificationThrower';
import { ReactComponent as Spinner } from '../../assets/svgIcons/spinner.svg';
import { ReactComponent as BackArrow } from '../../assets/svgIcons/back-arrow-svg.svg';
import { ReactComponent as BookmarkFillSvg } from '../../assets/svgIcons/bookmark-fill.svg';
import { ReactComponent as BookmarkSvg } from '../../assets/svgIcons/bookmark.svg';
import { ReactComponent as BrowseBook } from '../../assets/svgIcons/browse-book.svg';
import defaultCover from '../../assets/images/defaultBook.jpg';
import PDFFrame from '../../components/PDFViewer/PDFFrame';

import { Author } from '../../interfaces/books';
import { i18n } from '../../i18n';
import ConfirmWindow from '../../components/ConfirmWindow';

const SingleBookPage = () => {
  const { id } = useParams();
  const dispatch = useDispatch();
  const { singleBook } = useSelector(selectSingleBook);
  const navigate = useNavigate();
  const [modal, setModal] = useState(false);
  const [pageNumber, setPageNumber] = useState(1);
  const [favorite2, setFavorite2] = useState(singleBook?.favorite);
  const [payWall, setPayWall] = useState(false);
  const loading = useSelector(selectSingleBookLoading);
  useEffect(() => {
    dispatch(fetchSingleBook(id));
  }, []);

  useEffect(() => {
    setFavorite2(singleBook?.favorite);
    if (singleBook?.favorite) {
      singleBook.faqeTeLexuara === 0
        ? setPageNumber(1)
        : setPageNumber(singleBook.faqeTeLexuara);
    }
  }, [singleBook]);

  const handleProgresUpdate = () => {
    id &&
      dispatch(
        updateBookProgres({ faqeTeLexuara: pageNumber, id: Number(id) }),
      );
  };
  const [confirmRemove, setConfirmRemove] = useState(false);
  const handleRemoveFavorite = () => {
    dispatch(removeFromLibraria(id));
    setFavorite2(!favorite2);
  };
  const handleFavorite = (type: string) => {
    if (localStorage.getItem('idToken')) {
      switch (type) {
        case 'add':
          dispatch(
            saveInLibraria({
              libri: {
                id: id,
              },
              dataRegjistrimit: new Date().toISOString().slice(0, 10),
              faqeTeLexuara: pageNumber !== 1 ? pageNumber : 0,
            }),
          );
          setFavorite2(!favorite2);
          break;
        case 'remove':
          setConfirmRemove(true);
          break;
      }
    } else {
      notificationThrower({
        type: 'info',
        title: i18n(`singleBookPage.notifications.save`),
        duration: 5000,
      });
    }
  };

  const handleBrowseBook = () => {
    if (localStorage.getItem('idToken')) {
      if (singleBook?.mePagese) {
        setPayWall(true);
      } else {
        setModal(true);
      }
    } else {
      notificationThrower({
        type: 'info',
        title: i18n(`singleBookPage.notifications.read`),
        duration: 5000,
      });
    }
  };

  const userProgress = singleBook
    ? `${(singleBook.faqeTeLexuara / singleBook.nrFaqeve) * 100}%`
    : '0%';

  return (
    <>
      {singleBook && !loading ? (
        <div className="single-book-page">
          <main className="single-page-main">
            <div className="single-book-wraper">
              {payWall && (
                <ConfirmWindow toggle={setPayWall} openFile={setModal} />
              )}
              {modal && (
                <PDFFrame
                  pageNumber={pageNumber}
                  setPageNumber={e => setPageNumber(e)}
                  fileUrl={singleBook?.fileUrl}
                  setModal={(e: boolean) => setModal(e)}
                  isFavorite={favorite2}
                  handleProgresUpdate={handleProgresUpdate}
                />
              )}
              {confirmRemove && (
                <ConfirmWindow
                  toggleFavorite={setConfirmRemove}
                  libraryRemove={handleRemoveFavorite}
                />
              )}
              <BackArrow
                fill="#3f78e0"
                className="back-arrow-svg"
                onClick={() => navigate(-1)}
              />
              <div className="first-section">
                <div className="book-image-container">
                  <div className="book-actions">
                    <button
                      className="single-btn-primary"
                      onClick={() => {
                        !favorite2
                          ? handleFavorite('add')
                          : handleFavorite('remove');
                      }}
                    >
                      {!favorite2
                        ? i18n(`buttons.addLibrary`)
                        : i18n(`buttons.removeLibrary`)}
                      <div className="svg">
                        {!favorite2 ? (
                          <BookmarkSvg className="favorite-svg" />
                        ) : (
                          <BookmarkFillSvg
                            className="favorite-svg"
                            fill={'#3f78e0'}
                          />
                        )}
                      </div>
                    </button>
                    <button
                      className="btn-read"
                      onClick={() => handleBrowseBook()}
                    >
                      {i18n(`buttons.readBook`)}
                      <div className="svg">
                        <BrowseBook fill="white" />
                      </div>
                    </button>
                  </div>
                  <div className="book-cover-progres">
                    <img
                      src={singleBook?.imgUrl ?? defaultCover}
                      alt={singleBook?.imgName}
                      onError={({ currentTarget }) => {
                        currentTarget.onerror = null;
                        currentTarget.src = defaultCover;
                      }}
                    />
                    <span
                      className="book-progress"
                      style={{
                        width: userProgress,
                      }}
                    ></span>
                  </div>
                </div>

                <div>
                  <h1 className="book-name">{singleBook?.emri}</h1>
                  <hr />
                </div>
                <div className="book-primary-info">
                  <div className="info-piece">
                    <h3>{i18n(`singleBookPage.description`)}</h3>
                    <span className="book-description">
                      {singleBook?.pershkrimi}
                    </span>
                  </div>
                </div>
              </div>

              <div className="second-section">
                <div className="book-secondary-info">
                  <div id="more-info">
                    <h2 className="book-name">
                      {i18n(`singleBookPage.information`)}
                    </h2>
                    <hr />
                  </div>
                  <span className="info-piece">
                    {i18n(`singleBookPage.type`)}:{' '}
                    <b>{i18n(`selectOptions.type.${singleBook?.lloji}`)}</b>
                  </span>

                  <div className="info-piece">
                    <h3>{i18n(`singleBookPage.authors`)}</h3>
                    <div className="authors-container">
                      {singleBook?.autoreTeLibrave?.map(
                        (data: Author, index: any) => {
                          return (
                            <span
                              key={index}
                              className="single-author"
                              title={data?.emriPlote}
                            >
                              {data?.emriPlote}
                            </span>
                          );
                        },
                      )}
                      {singleBook?.autoreTeLibrave.length == 0 && (
                        <span>{i18n(`singleBookPage.noAuthors`)}</span>
                      )}
                    </div>
                  </div>
                  <div className="info-piece">
                    <h3>{i18n(`singleBookPage.category`)}</h3>
                    <div className="category-container">
                      {singleBook?.kategoriaList?.map((data, index) => {
                        return (
                          <span key={index} className="category-list">
                            {i18n(
                              `selectOptions.bookCategory.${data.listeKategoria}`,
                            )}
                          </span>
                        );
                      })}
                      {singleBook?.kategoriaList.length == 0 && (
                        <span>{i18n(`singleBookPage.noCategory`)}</span>
                      )}
                    </div>
                  </div>
                  <div className="info-piece">
                    <span>
                      {i18n(`singleBookPage.price`)}:
                      <b>
                        {singleBook?.mePagese
                          ? singleBook?.cmimi + ' Lekë'
                          : i18n(`singleBookPage.free`)}
                      </b>
                    </span>
                  </div>
                  <div className="info-piece">
                    <span>
                      {i18n(`singleBookPage.pageNr`)}:{' '}
                      <b>{singleBook?.nrFaqeve}</b>
                    </span>
                  </div>
                  <div className="info-piece">
                    <span>
                      {i18n(`singleBookPage.isbnCode`)}:{' '}
                      <b>{singleBook?.kodiISBN}</b>
                    </span>
                  </div>
                  <div className="info-piece">
                    <span>
                      {i18n(`singleBookPage.publishDate`)}:{' '}
                      <b>{singleBook?.dataPublikimit}</b>
                    </span>
                  </div>

                  <div className="info-piece">
                    <span>
                      {i18n(`singleBookPage.registerDate`)}:{' '}
                      <b>{singleBook?.dataRegjistrimit}</b>
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </main>
        </div>
      ) : loading ? (
        <div className="loader" key={0}>
          <Spinner className="spinner load-spin" />
        </div>
      ) : (
        <div style={{ margin: '50px' }}>{i18n(`noData`)}</div>
      )}
    </>
  );
};

export default SingleBookPage;
