import React, { useEffect, useState } from 'react';
import InputFormItem from '../../components/InputFormItem';
import TextAreaFormItem from '../../components/TextAreaFormItem';
import UploadBookCover from '../../components/UploadBookCover';
import UploadBook from '../../components/UploadBookMaterials';
import { ReactComponent as BackArrowSvg } from '../../assets/svgIcons/back-arrow-svg.svg';
import NewBookForm from '../../components/NewBookForm';
import * as yup from 'yup';
import SingleSelectFormItem from '../../components/SingleSelectFormItem';
import MultiSelectFormItem from '../../components/MultiSelectFormItem';
import {
  bookCategoryOptions,
  magazineCategoryOptions,
  fieldOptions,
  typeOptions,
} from '../../components/SelectOptions/selectFieldOptions';
import createBookDataTransformer from '../../helpers/crateBook/createCourseDataTransformer';
import { useDispatch, useSelector } from 'react-redux';
import {
  createBooks,
  resetBooksState,
  selectLoading,
  selectSuccess,
} from '../../redux/slices/Books/booksSlice';
import {
  selectAuthors,
  fetchAuthors,
} from '../../redux/slices/Authors/authorsSlice';
import authorsDataTransformer from '../../helpers/crateBook/authorsDataTransformer';
import { useNavigate } from 'react-router';
import { CheckBoxItem } from '../../components/CheckBoxInput';
import { i18n } from '../../i18n';

interface SelectOptionsProps {
  id?: any;
  value?: string;
  label?: string;
}
// interface CreateBooksProps {}

export const CreateBooks: React.FunctionComponent = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  useEffect(() => {
    dispatch(fetchAuthors(''));
  }, []);

  const authors = useSelector(selectAuthors);

  const schema = yup.object().shape({
    emri: yup.string().max(250).nullable().required(i18n(`bookErrors.name`)),
    pershkrimi: yup
      .string()
      .nullable()
      .required(i18n(`bookErrors.description`)),
    autoreTeLibrave: yup
      .array()
      .nullable()
      .required(i18n(`bookErrors.authors`)),
    lloji: yup.string().nullable().required(i18n(`bookErrors.type`)),
    kategoriaList: yup.array().nullable().required(i18n(`bookErrors.category`)),
    fushaList: yup.array().nullable().required(i18n(`bookErrors.field`)),
    dataPublikimit: yup
      .date()
      .nullable()
      .min('1900-01-01', i18n(`bookErrors.publishDate.minMax`))
      .max(new Date(), i18n(`bookErrors.publishDate.minMax`))
      .required(i18n(`bookErrors.publishDate.required`)),
    nrFaqeve: yup
      .number()
      .nullable()
      .positive()
      .typeError(i18n(`bookErrors.pageNr.required`))
      .min(1, i18n(`bookErrors.pageNr.min`))
      .required(i18n(`bookErrors.pageNr.required`)),
    kodiISBN: yup.string().nullable().required(i18n(`bookErrors.isbnCode`)),
    cmimi: yup
      .number()
      .positive()
      .typeError(i18n(`bookErrors.price.required`))
      .when('mePagese', {
        is: true,
        then: yup.number().nullable().min(1, i18n(`bookErrors.price.min`)),
        otherwise: yup.number().nullable().min(0, i18n(`bookErrors.price.min`)),
      })
      .required(i18n(`bookErrors.price.required`)),
    mePagese: yup.boolean().nullable(),
    file: yup.mixed().required(i18n(`bookErrors.file`)),
    image: yup.mixed(),
  });

  const [initalValues] = useState(() => {
    return {
      image: null,
      emri: null,
      pershkrimi: null,
      autoreTeLibrave: null,
      kategoriaList: null,
      fushaList: null,
      lloji: null,
      dataPublikimit: null,
      nrFaqeve: null,
      cmimi: null,
      mePagese: false,
      kodiISBN: null,
      file: null,
    };
  });
  const onHandleSuccess = (data: any) => {
    const transformedData = createBookDataTransformer(data);
    dispatch(createBooks(transformedData));
  };
  const onHandleError = () => {
    console.log('Error occured while adding a new book!');
  };
  const createdSuccess = useSelector(selectSuccess);
  const loading = useSelector(selectLoading);

  useEffect(() => {
    if (createdSuccess) {
      navigate('/');
      dispatch(resetBooksState());
    }
  }, [createdSuccess]);

  const [bookType, setBookType] = useState(null);
  const [kategoriValue, setKategoriValue] = useState(null);
  const [kategoriaList, setKategoriaList] =
    useState<Array<SelectOptionsProps>>();
  useEffect(() => {
    setKategoriValue(null);
    if (bookType === 'LIBER') {
      setKategoriaList(bookCategoryOptions);
    } else {
      setKategoriaList(magazineCategoryOptions);
    }
  }, [bookType]);

  return (
    <NewBookForm
      schema={schema}
      initialValues={initalValues}
      onHandleSuccess={onHandleSuccess}
      onHandleError={onHandleError}
    >
      <main className="create-books-main">
        <div className="wrapper">
          <div className="title">
            <BackArrowSvg
              className="back-arrow"
              onClick={() => navigate(-1)}
              fill="#3f78e0"
            />
            <h2>{i18n(`createBooksPage.header`)}</h2>
          </div>
          <div className="container">
            <UploadBookCover name="image" />
            <InputFormItem
              name="emri"
              label={i18n(`createBooksPage.placeholders.name`)}
              placeholder={i18n(`createBooksPage.placeholders.name`)}
            />
            <TextAreaFormItem
              name="pershkrimi"
              label={i18n(`createBooksPage.placeholders.description`)}
              placeholder={i18n(`createBooksPage.placeholders.description`)}
            />
            <MultiSelectFormItem
              name="autoreTeLibrave"
              label={i18n(`createBooksPage.placeholders.author`)}
              placeholder={i18n(`createBooksPage.placeholders.author`)}
              options={authorsDataTransformer(authors.authors)}
            />
            <div className="row-space-between">
              <SingleSelectFormItem
                name="lloji"
                placeholder={i18n(`createBooksPage.placeholders.type`)}
                options={typeOptions}
                onChange={(e: any) => setBookType(e.value)}
              />
              <MultiSelectFormItem
                name="kategoriaList"
                placeholder={i18n(`createBooksPage.placeholders.category`)}
                disabled={bookType === null}
                options={kategoriaList}
                selectValue={kategoriValue}
                onChange={(e: any) => {
                  setKategoriValue(e);
                }}
              />
            </div>
            <div className="row-space-between">
              <MultiSelectFormItem
                name="fushaList"
                placeholder={i18n(`createBooksPage.placeholders.field`)}
                options={fieldOptions}
              />
              <InputFormItem
                name="kodiISBN"
                label={i18n(`createBooksPage.placeholders.isbnCode`)}
                placeholder={i18n(`createBooksPage.placeholders.isbnCode`)}
                className="two-inputs"
              />
            </div>
            <div className="row-space-between">
              <InputFormItem
                name="dataPublikimit"
                label={i18n(`createBooksPage.placeholders.publishDate`)}
                placeholder={i18n(`createBooksPage.placeholders.publishDate`)}
                type="date"
                className="two-inputs"
                style={{ height: '42px' }}
              />
              <InputFormItem
                name="nrFaqeve"
                label={i18n(`createBooksPage.placeholders.pageNr`)}
                placeholder={i18n(`createBooksPage.placeholders.pageNr`)}
                type="number"
                className="two-inputs"
              />
            </div>
            <div className="row-space-between">
              <InputFormItem
                name="cmimi"
                label={i18n(`createBooksPage.placeholders.price`)}
                placeholder={i18n(`createBooksPage.placeholders.price`)}
                type="number"
                className="two-inputs"
              />
              <CheckBoxItem
                name="mePagese"
                label={i18n(`createBooksPage.placeholders.pay`)}
                className="two-inputs"
              />
            </div>
            <UploadBook name="file" />
            <button type="submit" className="btn-primary" disabled={loading}>
              {i18n(`buttons.saveBook`)}
            </button>
          </div>
        </div>
      </main>
    </NewBookForm>
  );
};
