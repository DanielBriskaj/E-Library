import { i18n } from '../i18n';

const TermsAndConditions = () => {
  return (
    <div className="terms-container">
      <div className="terms-wrapper">
        <h2>{i18n(`terms.title`)}</h2>
        <div className="terms-text">
          <h4>{i18n(`terms.terms1.title`)}</h4>
          {i18n(`terms.terms1.body`)}
        </div>
      </div>
    </div>
  );
};

export default TermsAndConditions;
