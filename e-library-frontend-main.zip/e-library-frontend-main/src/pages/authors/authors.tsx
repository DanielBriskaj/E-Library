import React, { useEffect, useState } from 'react';
import InfiniteScroll from 'react-infinite-scroller';
import { ReactComponent as Spinner } from '../../assets/svgIcons/spinner.svg';
import { useDispatch, useSelector } from 'react-redux';
import { ReactComponent as EditSvg } from '../../assets/svgIcons/card-edit.svg';
import DeleteWindow from '../../components/DeleteWindow';
import { FormProvider, useForm } from 'react-hook-form';
import debounce from 'lodash.debounce';
import InputFormItem from '../../components/InputFormItem';
import {
  deleteAuthor,
  fetchSingleAuthor,
  selectLoading,
} from '../../redux/slices/Authors/authorsSlice';
import { authorsApis } from '../../redux/slices/Authors/AuthorsApi';
import AuthorEdit from '../../components/EditAuthorWindow';
import CreateAuthor from '../../components/CreateAuthor';
import notificationThrower from '../../helpers/notificationThrower';
import { i18n } from '../../i18n';
import { ReactComponent as BackArrowSvg } from '../../assets/svgIcons/back-arrow-svg.svg';
import { useNavigate } from 'react-router';

export const Authors: React.FunctionComponent = () => {
  const [authorArray, setAuthorArray] = useState<Array<any>>([]);
  const [page, setPage] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  const [editAuthor, setEditAuthor] = useState(false);
  const [createAuthor, setCreateAuthor] = useState(false);
  const [searchName, setSearchName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const loading = useSelector(selectLoading);
  const handleGetAuthor = (id: number) => {
    dispatch(fetchSingleAuthor(id));
    setEditAuthor(!editAuthor);
  };
  const handleAuthorDelete = (id: number) => {
    dispatch(deleteAuthor(id));
  };

  useEffect(() => {
    if (authorArray.length !== 0 || !hasMore) {
      setAuthorArray([]);
      setPage(0);
      setHasMore(true);
    }
  }, [loading, searchName]);
  const loadMore = async (e: any) => {
    if (hasMore) {
      try {
        setIsLoading(true);
        const response = await authorsApis.fetchAuthors({
          emriPlote: searchName,
          page: page,
          size: 20,
          sort: ['emriPlote', 'asc'],
        });
        if (response.success) {
          setIsLoading(false);
          setAuthorArray(
            page !== 0
              ? [...authorArray, ...response.payload.data.autoret]
              : [...response.payload.data.autoret],
          );
          if (
            response.payload.data.faqjaAktuale ===
              response.payload.data.numriIFaqeve - 1 ||
            response.payload.data.numriIFaqeve == 0
          ) {
            setHasMore(false);
          }
          setPage(page + 1);
        }
      } catch (error) {
        notificationThrower({
          type: 'error',
          title: i18n(`noBackendError`),
          duration: 4000,
          message: i18n(`noBackendError`),
        });
      }
    }
  };
  const formConfig = useForm({
    reValidateMode: 'onBlur',
    mode: 'onChange',
  });

  const searchByName = (e: any) => {
    setSearchName(e?.target?.value);
  };
  const debounceByNameSearch = debounce(searchByName, 500);

  return (
    <div className="manage-authors-container">
      <div className="manage-authors-header">
        <div className="title">
          <BackArrowSvg
            className="back-arrow"
            onClick={() => navigate(-1)}
            fill="#3f78e0"
          />
          <h2>{i18n(`manageAuthors.title`)}</h2>
        </div>
        <div className="authors-filter-wrapper">
          <FormProvider {...formConfig}>
            <form className="filter-container">
              <InputFormItem
                name="search-name"
                placeholder={i18n(`manageAuthors.placeholders.search`)}
                onChange={debounceByNameSearch}
              />
            </form>
            <button
              type="button"
              className="btn-primary"
              onClick={() => setCreateAuthor(!createAuthor)}
            >
              {i18n(`manageAuthors.createAuthors.title`)}
            </button>
          </FormProvider>
        </div>
      </div>
      {createAuthor && <CreateAuthor toggle={setCreateAuthor} />}
      <div className="manage-authors-wrapper">
        <InfiniteScroll
          initialLoad
          pageStart={0}
          loadMore={e => loadMore(e)}
          hasMore={!isLoading && hasMore}
          loader={
            <div className="loader" key={0}>
              <Spinner className="spinner load-spin" />
            </div>
          }
        >
          <table className="authors-table-container">
            <thead>
              <tr className="table-row header">
                <th className="table-cell name">
                  {i18n(`manageAuthors.table.name`)}
                </th>
                <th className="table-cell birthday">
                  {i18n(`manageAuthors.table.birthday`)}
                </th>
                <th className="table-cell icons"></th>
              </tr>
            </thead>
            <tbody>
              {authorArray.length !== 0 ? (
                authorArray.map((data: any, index: number) => {
                  return (
                    <tr key={index} className="table-row">
                      <td className="table-cell name" title={data.emriPlote}>
                        <div className="ellipsis-div">{data.emriPlote}</div>
                      </td>
                      <td
                        className="table-cell birthday "
                        title={data.ditelindja}
                      >
                        <div className="ellipsis-div">
                          {data.ditelindja ? data.ditelindja : 'N/A'}
                        </div>
                      </td>
                      <td className="table-cell icons">
                        <EditSvg
                          className="edit-svg"
                          onClick={() => handleGetAuthor(Number(data.id))}
                          fill="#3f78e0"
                        />
                        <DeleteWindow
                          deleteAuthor={() =>
                            handleAuthorDelete(Number(data.id))
                          }
                        />
                      </td>
                    </tr>
                  );
                })
              ) : !isLoading && authorArray.length === 0 ? (
                <tr className="table-row" style={{ border: 'none' }}>
                  <td className="table-cell">{i18n(`noData`)}</td>
                </tr>
              ) : (
                <tr className="table-row" style={{ border: 'none' }}>
                  <td className="table-cell">Loading...</td>
                </tr>
              )}
              <tr>
                <td> {editAuthor && <AuthorEdit toggle={setEditAuthor} />}</td>
              </tr>
            </tbody>
          </table>
        </InfiniteScroll>
      </div>
    </div>
  );
};
