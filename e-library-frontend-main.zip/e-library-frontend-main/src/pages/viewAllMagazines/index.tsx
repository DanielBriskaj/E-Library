export { ViewAllMagazines as default } from './viewAllMagazines';
