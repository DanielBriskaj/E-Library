import React, { useEffect, useState } from 'react';
import Card from '../../components/Card';
import SingleSelectFormItem from '../../components/SingleSelectFormItem';
import {
  magazineCategoryOptions,
  fieldOptions,
  PayTypes,
} from '../../components/SelectOptions/selectFieldOptions';
import { FormProvider, useForm } from 'react-hook-form';
import InputFormItem from '../../components/InputFormItem';
import { ReactComponent as DownArrow } from '../../assets/svgIcons/down-arrow.svg';
import { ReactComponent as UpArrow } from '../../assets/svgIcons/up-arrow.svg';
import { ReactComponent as BackArrow } from '../../assets/svgIcons/back-arrow-svg.svg';
import { ReactComponent as Spinner } from '../../assets/svgIcons/spinner.svg';
import { ReactComponent as Filter } from '../../assets/svgIcons/filter.svg';
import { booksApis } from '../../redux/slices/Books/BooksApi';
import debounce from 'lodash.debounce';
import { useNavigate } from 'react-router-dom';
import InfiniteScroll from 'react-infinite-scroller';
import { resetBookState } from '../../redux/slices/Books/singleBookSlice';
import { useDispatch, useSelector } from 'react-redux';
import notificationThrower from '../../helpers/notificationThrower';
import { selectLoading } from '../../redux/slices/Books/booksSlice';
import { i18n } from '../../i18n';

interface ViewAllMagazinesProps {
  children: any;
}

export const ViewAllMagazines: React.FunctionComponent<
  ViewAllMagazinesProps
> = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const loading = useSelector(selectLoading);
  const [field, setField] = useState(null);
  const [category, setCategory] = useState(null);
  const [searchTitle, setSearchTitle] = useState('');
  const [searchAuthor, setSearchAuthor] = useState('');
  const [searchYear, setSearchYear] = useState('');
  const [searchPay, setSearchPay] = useState('te_gjithe');
  const [bookData, setBookData] = useState<Array<any>>([]);
  const [page, setPage] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  const [filterToggle, setFilterToggle] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [sort, setSort] = useState({
    by: 'id',
    order: 'desc',
    active: false,
  });

  useEffect(() => {
    dispatch(resetBookState());
  }, []);

  useEffect(() => {
    if (bookData.length !== 0 || !hasMore) {
      setBookData([]), setPage(0), setHasMore(true);
    }
  }, [
    searchTitle,
    category,
    field,
    sort,
    searchAuthor,
    searchYear,
    searchPay,
    loading,
  ]);

  const loadMore = async (e: any) => {
    if (hasMore) {
      try {
        setIsLoading(true);
        const response = await booksApis.fetchAllBooks({
          lloji: 'PERIODIK',
          emri: searchTitle,
          autori: searchAuthor,
          kategoria: category,
          fusha: field,
          sort: [sort.by, sort.order],
          page: page,
          vitiPublikimit: searchYear,
          mePagese: searchPay,
        });

        if (response.success) {
          setIsLoading(false);
          setBookData(
            page !== 0
              ? [...bookData, ...response.payload.data.librat]
              : [...response.payload.data.librat],
          );
          if (
            response.payload.data.faqjaAktuale ===
              response.payload.data.numriIFaqeve - 1 ||
            response.payload.data.numriIFaqeve == 0
          ) {
            setHasMore(false);
          }
          setPage(page + 1);
        }
      } catch (error) {
        notificationThrower({
          type: 'error',
          title: i18n(`noBackendError`),
          duration: 4000,
          message: i18n(`noBackendError`),
        });
      }
    }
  };
  const SetBookOrder = () => {
    if (sort.by === 'id' && sort.order === 'desc') {
      setSort({ by: 'emri', order: 'asc', active: true });
    } else if (sort.by === 'emri' && sort.order === 'asc') {
      setSort({ by: 'emri', order: 'desc', active: true });
    } else {
      setSort({ by: 'emri', order: 'asc', active: true });
    }
  };

  const formConfig = useForm({
    reValidateMode: 'onBlur',
    mode: 'onChange',
  });
  const searchRevist = (e: any) => {
    setSearchTitle(e?.target?.value);
  };
  const debounceRevistSearch = debounce(searchRevist, 500);
  const searchAuth = (e: any) => {
    setSearchAuthor(e?.target?.value);
  };
  const debounceAuthorSearch = debounce(searchAuth, 500);
  const searchByYear = (e: any) => {
    setSearchYear(e?.target?.value);
  };
  const debounceYearSearch = debounce(searchByYear, 500);
  return (
    <main className="all-books-container">
      <div className="view-books-wrapper">
        <div className="view-books-header">
          <div className="flex-title">
            <div className="title">
              <span onClick={() => navigate(-1)}>
                <BackArrow fill="#3f78e0" className="back-arrow-svg" />
              </span>
              <h2>{i18n(`navbar.main.periodic`)}</h2>
            </div>
            <span
              className="filter-svg2-container"
              onClick={() => setFilterToggle(!filterToggle)}
            >
              {!filterToggle ? i18n(`filters.filter`) : ''}
              <Filter
                className="filter-svg2"
                style={{ width: '25px', height: '25px', cursor: 'pointer' }}
              />
            </span>
          </div>
          <div className="filter-wrapper">
            <FormProvider {...formConfig}>
              <form
                className={`
                ${filterToggle ? 'slide-in' : 'slide-out'} 
                filter-container`}
              >
                <span
                  className="filter-svg-container"
                  onClick={() => setFilterToggle(!filterToggle)}
                >
                  {!filterToggle ? (
                    <span className="filtro">{i18n(`filters.filter`)}</span>
                  ) : (
                    ''
                  )}
                  <Filter
                    className="filter-svg"
                    style={{
                      width: '25px',
                      height: '25px',
                      cursor: 'pointer',
                    }}
                  />
                </span>
                <div
                  className="asc-filter"
                  onClick={SetBookOrder}
                  style={sort.active ? { borderColor: '#3f78e0' } : {}}
                >
                  {sort.order === 'desc' ? (
                    <span style={sort.active ? { color: '#3f78e0' } : {}}>
                      {i18n(`filters.sortAZ`)}
                      <DownArrow
                        className="arrow-svg"
                        style={sort.active ? { fill: '#3f78e0' } : {}}
                      />{' '}
                    </span>
                  ) : (
                    <span style={sort.active ? { color: '#3f78e0' } : {}}>
                      {i18n(`filters.sortZA`)}
                      <UpArrow
                        className="arrow-svg"
                        style={sort.active ? { fill: '#3f78e0' } : {}}
                      />
                    </span>
                  )}
                </div>
                <div className="two-filters-container">
                  <InputFormItem
                    name="search-bar"
                    placeholder={i18n(`filters.searchTitle`)}
                    onChange={debounceRevistSearch}
                  />
                  <InputFormItem
                    name="search-author"
                    placeholder={i18n(`filters.searchAuthor`)}
                    onChange={debounceAuthorSearch}
                  />
                </div>
                <div className="two-filters-container">
                  <InputFormItem
                    name="search-year"
                    placeholder={i18n(`filters.searchYear`)}
                    onChange={debounceYearSearch}
                    type="number"
                  />
                  <SingleSelectFormItem
                    name="kategoriFilter"
                    placeholder={i18n(`filters.category`)}
                    options={magazineCategoryOptions}
                    onChange={(e: any) => setCategory(e?.value ?? null)}
                    isClearable
                  />
                </div>
                <div className="two-filters-container">
                  <SingleSelectFormItem
                    name="fieldFilter"
                    placeholder={i18n(`filters.field`)}
                    options={fieldOptions}
                    onChange={(e: any) => setField(e?.value ?? null)}
                    isClearable
                  />
                  <SingleSelectFormItem
                    name="mePagese"
                    placeholder={i18n(`filters.payment`)}
                    options={PayTypes}
                    onChange={(e: any) => setSearchPay(e?.value ?? null)}
                    isClearable
                  />
                </div>
              </form>
            </FormProvider>
          </div>
        </div>
        <InfiniteScroll
          initialLoad
          pageStart={0}
          loadMore={e => loadMore(e)}
          hasMore={!isLoading && hasMore}
          loader={
            <div className="loader" key={0}>
              <Spinner className="spinner load-spin" />
            </div>
          }
        >
          <div className="books-container">
            {bookData.length !== 0 ? (
              bookData?.map((data: any, index: number) => {
                const props = {
                  id: data.id,
                  title: data.emri,
                  image: data.imgUrl,
                  favorite: data.favorite,
                  category: data.kategoriaList,
                  page_nr: data.nrFaqeve,
                  authors: data.autoreTeLibrave,
                  userProgress: (data.faqeTeLexuara / data.nrFaqeve) * 100,
                };
                return <Card key={index} {...props} />;
              })
            ) : !isLoading && bookData.length === 0 ? (
              <span style={{ width: '100%' }}>{i18n(`noData`)}</span>
            ) : (
              'Loading...'
            )}
          </div>
        </InfiniteScroll>
      </div>
    </main>
  );
};
