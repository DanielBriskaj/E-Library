import React, { useEffect, useState } from 'react';
import InfiniteScroll from 'react-infinite-scroller';
import { usersApis } from '../../redux/slices/Users/usersApi';
import { ReactComponent as Spinner } from '../../assets/svgIcons/spinner.svg';
import { useDispatch, useSelector } from 'react-redux';
import { ReactComponent as EditSvg } from '../../assets/svgIcons/card-edit.svg';
import { ReactComponent as BackArrowSvg } from '../../assets/svgIcons/back-arrow-svg.svg';
import {
  deleteUser,
  downloadUsers,
  fetchSingleUser,
  selectLoading,
} from '../../redux/slices/Users/usersSlice';
import DeleteWindow from '../../components/DeleteWindow';
import UserEdit from '../../components/UserEditPopUp';
import { FormProvider, useForm } from 'react-hook-form';
import debounce from 'lodash.debounce';
import InputFormItem from '../../components/InputFormItem';
import SingleSelectFormItem from '../../components/SingleSelectFormItem';
import { userTypeOptions } from '../../components/SelectOptions/selectFieldOptions';
import { getEmail } from '../../helpers/getUserRole';
import notificationThrower from '../../helpers/notificationThrower';
import { i18n } from '../../i18n';
import { useNavigate } from 'react-router';

export const ManageUsers: React.FunctionComponent = () => {
  const userName = getEmail();
  const [userArray, setUserArray] = useState<Array<any>>([]);
  const [page, setPage] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  const loading = useSelector(selectLoading);
  const [editUser, setEditUser] = useState(false);
  const [searchName, setSearchName] = useState('');
  const [searchLastName, setSearchLastName] = useState('');
  const [userType, setUserType] = useState();
  const [isLoading, setIsLoading] = useState(false);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const handleGetUser = (id: number) => {
    setEditUser(!editUser);
    dispatch(fetchSingleUser(id));
  };
  const handleUserDelete = (id: number) => {
    dispatch(deleteUser(id));
  };

  useEffect(() => {
    if (userArray.length !== 0 || !hasMore) {
      setUserArray([]);
      setPage(0);
      setHasMore(true);
    }
  }, [loading, userType, searchName, searchLastName]);
  const loadMore = async (e: any) => {
    if (hasMore) {
      try {
        setIsLoading(true);
        const response = await usersApis.fetchUsers({
          tipPerdorues: userType,
          emri: searchName,
          mbiemri: searchLastName,
          page: page,
          size: 20,
          sort: ['aprovuar', 'asc'],
        });
        if (response.success) {
          setIsLoading(false);
          setUserArray(
            page !== 0
              ? [...userArray, ...response.payload.data.perdoruesit]
              : [...response.payload.data.perdoruesit],
          );
          if (
            response.payload.data.faqjaAktuale ===
              response.payload.data.gjithaFaqet - 1 ||
            response.payload.data.gjithaFaqet == 0
          ) {
            setHasMore(false);
          }
          setPage(page + 1);
        }
      } catch (error) {
        notificationThrower({
          type: 'error',
          title: i18n(`noBackendError`),
          duration: 4000,
          message: i18n(`noBackendError`),
        });
      }
    }
  };
  const formConfig = useForm({
    reValidateMode: 'onBlur',
    mode: 'onChange',
  });

  const searchByName = (e: any) => {
    setSearchName(e?.target?.value);
  };
  const debounceByNameSearch = debounce(searchByName, 500);
  const searchByLast = (e: any) => {
    setSearchLastName(e?.target?.value);
  };
  const debounceByLastSearch = debounce(searchByLast, 500);

  const downloadingUsers = (e: any) => {
    dispatch(
      downloadUsers({
        emri: searchName,
        mbiemri: searchLastName,
        tipPerdorues: userType,
      }),
    );
  };
  return (
    <div className="manage-users-container">
      <div className="manage-users-header">
        <div className="title">
          <BackArrowSvg
            className="back-arrow"
            onClick={() => navigate(-1)}
            fill="#3f78e0"
          />
          <h2>{i18n(`manageUsers.title`)}</h2>
        </div>
        <div className="user-filter-wrapper">
          <FormProvider {...formConfig}>
            <form className="user-filter-container">
              <InputFormItem
                name="search-name"
                placeholder={i18n(`manageUsers.placeholders.searchName`)}
                onChange={debounceByNameSearch}
              />
              <InputFormItem
                name="search-lastname"
                placeholder={i18n(`manageUsers.placeholders.searchLastName`)}
                onChange={debounceByLastSearch}
              />
              <SingleSelectFormItem
                name="userTypeFilter"
                placeholder={i18n(`manageUsers.placeholders.type`)}
                options={userTypeOptions}
                onChange={(e: any) => setUserType(e?.value ?? null)}
                isClearable
              />
              <button
                type="button"
                className="btn-primary"
                onClick={downloadingUsers}
              >
                {i18n(`buttons.downloadUsers`)}
              </button>
            </form>
          </FormProvider>
        </div>
      </div>
      <div className="manage-users-wrapper">
        <InfiniteScroll
          initialLoad
          pageStart={0}
          loadMore={e => loadMore(e)}
          hasMore={!isLoading && hasMore}
          loader={
            <div className="loader" key={0}>
              <Spinner className="spinner load-spin" />
            </div>
          }
        >
          <table className="user-container">
            <thead>
              <tr className="table-row header">
                <th className="table-cell name">
                  {i18n(`manageUsers.table.name`)}
                </th>
                <th className="table-cell email">
                  {i18n(`manageUsers.table.email`)}
                </th>
                <th className="table-cell role">
                  {i18n(`manageUsers.table.role`)}
                </th>
                <th className="table-cell user-type">
                  {i18n(`manageUsers.table.type`)}
                </th>
                <th className="table-cell status">
                  {i18n(`manageUsers.table.status.title`)}
                </th>
                <th className="table-cell icons"></th>
              </tr>
            </thead>
            <tbody>
              {userArray.length !== 0 ? (
                userArray.map((data: any, index: number) => {
                  return (
                    <tr key={index} className="table-row">
                      <td
                        className="table-cell name"
                        title={data.emri + ' ' + data.mbiemri}
                      >
                        <div className="ellipsis-div">
                          {data.emri} {data.mbiemri}
                        </div>
                      </td>
                      <td className="table-cell email " title={data.email}>
                        <div className="ellipsis-div"> {data.email}</div>
                      </td>
                      <td
                        className="table-cell role"
                        title={i18n(`selectOptions.userRole.${data.roli}`)}
                      >
                        {data?.roli
                          ? i18n(`selectOptions.userRole.${data.roli}`)
                          : 'N/A'}
                      </td>
                      <td
                        className="table-cell user-type"
                        title={i18n(
                          `selectOptions.userType.${data.tipPerdorues}`,
                        )}
                      >
                        <div className="ellipsis-div">
                          {' '}
                          {data?.tipPerdorues
                            ? i18n(
                                `selectOptions.userType.${data.tipPerdorues}`,
                              )
                            : 'N/A'}
                        </div>
                      </td>
                      <td className="table-cell status">
                        <span
                          className="single-status"
                          style={
                            data.aprovuar
                              ? {
                                  color: 'rgb(48 181 48)',
                                }
                              : {
                                  color: '#e31212',
                                }
                          }
                        >
                          {data.aprovuar
                            ? i18n(`manageUsers.table.status.active`)
                            : i18n(`manageUsers.table.status.inactive`)}
                        </span>
                      </td>

                      <td className="table-cell icons">
                        {data?.email === userName ? (
                          ''
                        ) : (
                          <>
                            <EditSvg
                              className="edit-svg"
                              onClick={() => handleGetUser(Number(data.id))}
                              fill="#3f78e0"
                            />
                            <DeleteWindow
                              deleteUser={() =>
                                handleUserDelete(Number(data.id))
                              }
                            />
                          </>
                        )}
                      </td>
                    </tr>
                  );
                })
              ) : !isLoading && userArray.length === 0 ? (
                <tr className="table-row" style={{ border: 'none' }}>
                  <td className="table-cell">{i18n(`noData`)}</td>
                </tr>
              ) : (
                <tr className="table-row" style={{ border: 'none' }}>
                  <td className="table-cell">Loading...</td>
                </tr>
              )}
              <tr>
                <td>{editUser && <UserEdit toggle={setEditUser} />}</td>
              </tr>
            </tbody>
          </table>
        </InfiniteScroll>
      </div>
    </div>
  );
};
