import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { RootState } from '../../store';
import { booksApis } from './BooksApi';
import notificationThrower from '../../../helpers/notificationThrower';
import { Book } from '../../../interfaces/books';
import { i18n } from '../../../i18n';

interface BookState {
  books: Array<Book>;
  homePageData: {
    homeBooks: Array<Book>;
    homeRevist: Array<Book>;
  };
  loading: boolean;
  error: string | null;
  currentPage: number;
  success: boolean;
}

const initialState: BookState = {
  books: [],
  homePageData: {
    homeBooks: [],
    homeRevist: [],
  },
  loading: false,
  error: null,
  currentPage: 0,
  success: false,
};

export const createBooks = createAsyncThunk<
  { books: any; success: boolean },
  any,
  { rejectValue: { payload: any; success: boolean; status: number } }
>('books/createBooks', async (query, thunkApi) => {
  const response = await booksApis.crateBook(query.bookData);

  if (response.success) {
    const files = new FormData();
    files.append('id', response.payload.data.id);
    files.append('file', query.bookFiles.file);
    files.append('image', query.bookFiles.image);
    thunkApi.dispatch(postBookResourses(files));
  }
  return response.data;
});

export const postBookResourses = createAsyncThunk<
  { payload: any; files: any; success: boolean },
  any,
  { rejectValue: { payload: any; success: boolean; status: number } }
>('books/postBookResourses', async query => {
  const response = await booksApis.postBookResourses(query);
  return response;
});

export const fetchBooks = createAsyncThunk('books/fetchBooks', async data => {
  const response = await booksApis.fetchBooks();
  return response;
});

export const updateBookProgres = createAsyncThunk(
  'books/updateBookProgres',
  async (args: { faqeTeLexuara: number; id: number }, { rejectWithValue }) => {
    try {
      const response = await booksApis.updateBookProgres(
        Number(args.faqeTeLexuara),
        args.id,
      );
      return response;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  },
);

export const fetchHomePageData = createAsyncThunk(
  'books/fetchHomePageData',
  async (args: { query: any; type: string }, { rejectWithValue }) => {
    try {
      const response = await booksApis.fetchHomePageData(args.query);
      return { type: args.type, response: response };
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  },
);

export const updateBookData = createAsyncThunk(
  'books/updateBookData',
  async (args: { data: any; id: number }, { rejectWithValue }) => {
    try {
      const response = await booksApis.updateBookData(args.data, args.id);
      return response;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  },
);

export const updateBookFile = createAsyncThunk<
  { payload: any; files: any; success: boolean },
  any,
  { rejectValue: { payload: any; success: boolean; status: number } }
>('books/updateBookFile', async (args: { data: any; id: any }) => {
  const file = new FormData();
  file.append('id', args.id);
  file.append('file', args.data);
  const response = await booksApis.updateBookFile(file);
  return response;
});

export const updateBookImage = createAsyncThunk<
  { payload: any; files: any; success: boolean },
  any,
  { rejectValue: { payload: any; success: boolean; status: number } }
>('books/updateBookImage', async (args: { data: any; id: any }) => {
  const image = new FormData();
  image.append('id', args.id);
  image.append('file', args.data);
  const response = await booksApis.updateBookImage(image);
  return response;
});
export const deleteBook = createAsyncThunk(
  'books/deleteBook',
  async (id: number, { rejectWithValue }) => {
    try {
      const response = await booksApis.deleteBook(id);
      return response;
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  },
);
export const booksSlice = createSlice({
  name: 'books',
  initialState,
  reducers: {
    resetBooksState: () => initialState,
  },
  extraReducers: builder => {
    builder
      .addCase(fetchBooks.pending, state => {
        return {
          ...state,
          loading: true,
        };
      })
      .addCase(fetchBooks.fulfilled, (state, action) => {
        return {
          ...state,
          books: action.payload.payload.data.librat,
          currentPage: action.payload.payload.data.currentPage,
          loading: false,
        };
      })
      .addCase(fetchBooks.rejected, (state, action) => {
        notificationThrower({
          type: 'error',
          title: i18n(`noBackendError`),
          duration: 6000,
          message: i18n(`noBackendError`),
        });
        return {
          ...state,
          error: action.error.message as any,
          loading: false,
        };
      })
      .addCase(fetchHomePageData.pending, state => {
        return {
          ...state,
          loading: true,
        };
      })
      .addCase(fetchHomePageData.fulfilled, (state, action) => {
        if (action.payload.type === 'revist') {
          state.homePageData.homeRevist = action.payload.response.payload.data;
        } else {
          state.homePageData.homeBooks = action.payload.response.payload.data;
        }
        state.loading = false;
      })
      .addCase(fetchHomePageData.rejected, (state, action) => {
        notificationThrower({
          type: 'error',
          title: i18n(`noBackendError`),
          duration: 4000,
          message: i18n(`noBackendError`),
        });
        return {
          ...state,
          error: action.payload as any,
          loading: false,
        };
      })
      .addCase(updateBookProgres.rejected, (state, action) => {
        notificationThrower({
          type: 'error',
          title: i18n(`notifications.progressNoSave`),
          duration: 6000,
          message: i18n(`notifications.progressNoSave`),
        });
        return {
          ...state,
          error: action.payload as any,
        };
      })
      .addCase(createBooks.pending, state => {
        return {
          ...state,
          loading: true,
        };
      })
      .addCase(createBooks.fulfilled, (state, action) => {
        notificationThrower({
          type: 'success',
          title: i18n(`notifications.bookSaved.title`),
          duration: 7000,
          message: i18n(`notifications.bookSaved.message`) as string,
        });
        return {
          ...state,
          books: [],
          loading: false,
        };
      })
      .addCase(createBooks.rejected, (state, action) => {
        notificationThrower({
          type: 'error',
          title: i18n(`noBackendError`),
          duration: 4000,
          message: i18n(`noBackendError`),
        });
        return {
          ...state,
          error: action.error.message as any,
          loading: false,
        };
      })
      .addCase(postBookResourses.pending, state => {
        return {
          ...state,
          loading: true,
          success: false,
        };
      })
      .addCase(postBookResourses.fulfilled, (state, action) => {
        notificationThrower({
          type: 'success',
          title: i18n(`notifications.bookFile`),
          duration: 6000,
        });
        return {
          ...state,
          loading: false,
          success: true,
        };
      })
      .addCase(postBookResourses.rejected, (state, action) => {
        if (action.error.message === 'Request failed with status code 400') {
          notificationThrower({
            type: 'error',
            title: i18n(`requestErrors.createBook.wrongRSS`),
            duration: 6000,
            message: i18n(`requestErrors.createBook.wrongRSS`),
          });
        } else {
          notificationThrower({
            type: 'error',
            title: i18n(`noBackendError`),
            duration: 4000,
            message: i18n(`noBackendError`),
          });
        }
        return {
          ...state,
          error: action.error.message as any,
          loading: false,
          success: false,
        };
      })
      .addCase(updateBookData.pending, state => {
        return {
          ...state,
          loading: true,
          success: false,
        };
      })
      .addCase(updateBookData.fulfilled, state => {
        notificationThrower({
          type: 'success',
          title: i18n(`notifications.bookSaved.title`),
          duration: 7000,
        });
        return {
          ...state,
          books: [],
          loading: false,
          success: true,
        };
      })
      .addCase(updateBookData.rejected, (state, action) => {
        notificationThrower({
          type: 'error',
          title: i18n(`noBackendError`),
          duration: 6000,
          message: i18n(`noBackendError`),
        });
        return {
          ...state,
          error: action.payload as any,
          loading: false,
          success: false,
        };
      })
      .addCase(updateBookFile.pending, state => {
        return {
          ...state,
          loading: true,
        };
      })
      .addCase(updateBookFile.fulfilled, state => {
        notificationThrower({
          type: 'success',
          title: i18n(`notifications.bookFile`),
          duration: 7000,
        });
        return {
          ...state,
          loading: false,
        };
      })
      .addCase(updateBookFile.rejected, (state, action) => {
        if (action.error.message === 'Request failed with status code 400') {
          notificationThrower({
            type: 'error',
            title: i18n(`requestErrors.createBook.wrongFile`),
            duration: 6000,
            message: i18n(`requestErrors.createBook.wrongFile`),
          });
        } else {
          notificationThrower({
            type: 'error',
            title: i18n(`noBackendError`),
            duration: 4000,
            message: i18n(`noBackendError`),
          });
        }
        return {
          ...state,
          error: action.error.message as any,
          loading: false,
        };
      })
      .addCase(updateBookImage.pending, state => {
        return {
          ...state,
          loading: true,
        };
      })
      .addCase(updateBookImage.fulfilled, state => {
        notificationThrower({
          type: 'success',
          title: i18n(`notifications.bookImg`),
          duration: 7000,
        });
        return {
          ...state,
          loading: false,
        };
      })
      .addCase(updateBookImage.rejected, (state, action) => {
        if (action.error.message === 'Request failed with status code 400') {
          notificationThrower({
            type: 'error',
            title: i18n(`requestErrors.createBook.wrongImg`),
            duration: 6000,
            message: i18n(`requestErrors.createBook.wrongImg`),
          });
        } else {
          notificationThrower({
            type: 'error',
            title: i18n(`noBackendError`),
            duration: 4000,
            message: i18n(`noBackendError`),
          });
        }
        return {
          ...state,
          error: action.payload as any,
          loading: false,
        };
      })
      .addCase(deleteBook.pending, state => {
        return {
          ...state,
          loading: true,
        };
      })
      .addCase(deleteBook.fulfilled, state => {
        notificationThrower({
          type: 'success',
          title: i18n(`notifications.bookDeleted`),
          duration: 6000,
          message: '',
        });
        return {
          ...state,
          loading: false,
        };
      })
      .addCase(deleteBook.rejected, (state, action) => {
        notificationThrower({
          type: 'error',
          title: i18n(`noBackendError`),
          duration: 4000,
          message: i18n(`noBackendError`),
        });
        return {
          ...state,
          error: action.payload as any,
          loading: false,
        };
      });
  },
});

export const { resetBooksState } = booksSlice.actions;

export const selectBooks = (state: RootState) => state.books;
export const selectHomePageData = (state: RootState) =>
  state.books.homePageData;
export const selectErrorMessage = (state: RootState) => state.books.error;
export const selectLoading = (state: RootState) => state.books.loading;
export const selectSuccess = (state: RootState) => state.books.success;
export default booksSlice.reducer;
