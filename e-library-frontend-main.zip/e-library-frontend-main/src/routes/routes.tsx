import React from 'react';
import CostumLoadable from '../components/Loaders/CostumLoadable';
import routesWithPermissions from './routesWithPermissions';

type Route = {
  caseSensitive?: boolean;
  children?: Route[];
  element?: React.ReactNode;
  path?: string;
};

const HomePageLoader = () => import('../pages/Home');
const ViewAllBooksLoader = () => import('../pages/viewAllBooks');
const ViewAllMagazinesLoader = () => import('../pages/viewAllMagazines');
const MyLibraryLoader = () => import('../pages/myLibrary');
const CreateBooks = () => import('../pages/createBooks/index');
const EditBooks = () => import('../pages/editBook');
const Login = () => import('../pages/auth/login');
const Register = () => import('../pages/auth/register');
const SingleBook = () => import('../pages/singleBook/singleBookPage');
const Authors = () => import('../pages/authors');
const ManageUsers = () => import('../pages/manageUsers');
const PersonalAccount = () => import('../pages/userPersonalEdit');
const TermsAndConditions = () => import('../pages/Terms');
const NotFound = () => import('../pages/NotFound');
const SendEmail = () => import('../pages/sendEmail');
const routes: Route[] = [
  {
    path: '/',
    element: <CostumLoadable loader={HomePageLoader} path="/" />,
  },
  {
    path: '/books',
    element: <CostumLoadable loader={ViewAllBooksLoader} path="/books" />,
  },
  {
    path: '/manage/books',
    element: (
      <CostumLoadable loader={ViewAllBooksLoader} path="/manage/books" />
    ),
  },
  {
    path: '/read-books/:id',
    element: <CostumLoadable loader={SingleBook} path="/read-books/:id" />,
  },
  {
    path: '/manage/edit-books/:id',
    element: (
      <CostumLoadable loader={EditBooks} path="/manage/edit-books/:id" />
    ),
  },
  {
    path: '/magazines',
    element: (
      <CostumLoadable loader={ViewAllMagazinesLoader} path="/magazines" />
    ),
  },
  {
    path: '/manage/magazines',
    element: (
      <CostumLoadable
        loader={ViewAllMagazinesLoader}
        path="/manage/magazines"
      />
    ),
  },
  {
    path: '/library',
    element: <CostumLoadable loader={MyLibraryLoader} path="/library" />,
  },
  {
    path: '/manage/create-book',
    element: <CostumLoadable loader={CreateBooks} path="/manage/create-book" />,
  },
  {
    path: '/manage',
    element: <CostumLoadable loader={ManageUsers} path="/manage" />,
  },
  {
    path: '/login',
    element: <CostumLoadable loader={Login} path="/login" />,
  },
  {
    path: '/register',
    element: <CostumLoadable loader={Register} path="/register" />,
  },
  {
    path: '/manage/authors',
    element: <CostumLoadable loader={Authors} path="/manage/authors" />,
  },
  {
    path: '/account',
    element: <CostumLoadable loader={PersonalAccount} path="/account" />,
  },
  {
    path: '/terms-and-conditions',
    element: (
      <CostumLoadable
        loader={TermsAndConditions}
        path="/terms-and-conditions"
      />
    ),
  },
  { path: '/404', element: <CostumLoadable loader={NotFound} path="/404" /> },
  {
    path: '/manage/send-email',
    element: <CostumLoadable loader={SendEmail} path="/manage/send-email" />,
  },
];

export default routes;
