import React, { useState } from 'react';
import { useRoutes } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import routes from './routes/routes';
import BackToTop from './components/BackToTop';

function App() {
  const renderRoutes = useRoutes(routes);
  return (
    <div className="App">
      <Navbar />
      <div
        className="global-wrapper"
        style={{ padding: '0 6%', minHeight: '400px' }}
      >
        {renderRoutes}
      </div>
      <BackToTop />
      <Footer />
    </div>
  );
}

export default App;
