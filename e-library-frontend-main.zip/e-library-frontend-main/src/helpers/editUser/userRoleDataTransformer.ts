import { User } from '../../interfaces/users';

const userRoleDataTransformer = (data: User) => {
  return {
    aprovuar: data.aprovuar,
    roli: data.roli,
    tipPerdorues: data.tipPerdorues,
  };
};

export default userRoleDataTransformer;

export const userInfoDataTransformer = (data: User) => {
  return {
    emri: data.emri,
    mbiemri: data.mbiemri,
    username: data.username,
  };
};
