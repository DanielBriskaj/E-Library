import { Author } from '../interfaces/books';
import { dateTransform } from './dateTransform';

export const createAuthorTransformer = (data: Author) => {
  return {
    emriPlote: data.emriPlote,
    ditelindja: dateTransform(data.ditelindja),
  };
};
