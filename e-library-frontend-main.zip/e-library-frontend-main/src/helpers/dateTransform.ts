export const dateTransform = (date: any) => {
  const before = new Date(date);

  const transform =
    before.getFullYear() +
    '-' +
    (Number(before.getMonth()) < 9
      ? '0' + (Number(before.getMonth()) + 1)
      : Number(before.getMonth()) + 1) +
    '-' +
    (Number(before.getDate()) < 10
      ? '0' + Number(before.getDate())
      : Number(before.getDate()));

  return transform;
};
